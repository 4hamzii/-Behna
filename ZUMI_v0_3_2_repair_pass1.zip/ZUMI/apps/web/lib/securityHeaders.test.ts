import { describe, expect, it } from "vitest";
import { buildSecurityHeaders } from "./securityHeaders";

const find = (h: { key: string; value: string }[], k: string) => h.find((x) => x.key === k)?.value;

describe("buildSecurityHeaders", () => {
  it("blocks framing and object embeds", () => {
    const csp = find(buildSecurityHeaders({ isProd: true, apiUrl: "https://api.example.test" }), "Content-Security-Policy");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain("object-src 'none'");
  });
  it("allows unsafe-eval only outside production", () => {
    const dev = find(buildSecurityHeaders({ isProd: false, apiUrl: "http://localhost:4000" }), "Content-Security-Policy");
    const prod = find(buildSecurityHeaders({ isProd: true, apiUrl: "http://localhost:4000" }), "Content-Security-Policy");
    expect(dev).toContain("'unsafe-eval'");
    expect(prod).not.toContain("'unsafe-eval'");
  });
  it("sends HSTS only in production", () => {
    expect(find(buildSecurityHeaders({ isProd: true, apiUrl: "x" }), "Strict-Transport-Security")).toBeDefined();
    expect(find(buildSecurityHeaders({ isProd: false, apiUrl: "x" }), "Strict-Transport-Security")).toBeUndefined();
  });
});
