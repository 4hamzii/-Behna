export interface Header {
  key: string;
  value: string;
}

/**
 * Security headers for the web app.
 * Note: Next.js injects small inline scripts, so script-src needs 'unsafe-inline'
 * until a nonce-based CSP is added (tracked in docs/KNOWN_ISSUES.md).
 */
export function buildSecurityHeaders(opts: { isProd: boolean; apiUrl: string }): Header[] {
  const scriptSrc = ["'self'", "'unsafe-inline'", ...(opts.isProd ? [] : ["'unsafe-eval'"])];
  const csp = [
    "default-src 'self'",
    `script-src ${scriptSrc.join(" ")}`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self'",
    `connect-src 'self' ${opts.apiUrl}`,
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'"
  ].join("; ");

  const headers: Header[] = [
    { key: "Content-Security-Policy", value: csp },
    { key: "X-Content-Type-Options", value: "nosniff" },
    { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
    { key: "X-Frame-Options", value: "DENY" },
    { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" }
  ];
  if (opts.isProd) {
    headers.push({ key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" });
  }
  return headers;
}
