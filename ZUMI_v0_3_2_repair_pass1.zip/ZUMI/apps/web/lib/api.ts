const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

export interface ApiResult { ok: boolean; status: number; data: { message?: string; error?: string; issues?: { path: string; message: string }[]; user?: { id: string; email: string } } }

/** POST/GET JSON to the ZUMI API. Cookies are sent so the session works. Never throws on HTTP errors. */
export async function api(path: string, method: "GET" | "POST", body?: unknown): Promise<ApiResult> {
  try {
    const res = await fetch(`${API}${path}`, {
      method,
      credentials: "include",
      headers: body ? { "Content-Type": "application/json" } : {},
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    const data = res.status === 204 ? {} : await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data };
  } catch {
    return { ok: false, status: 0, data: { message: "Cannot reach the server. Check your connection." } };
  }
}
