import AuthForm from "../../components/AuthForm";
export default function Page() {
  return <AuthForm title="Log in" path="/api/v1/auth/login" submitLabel="Log in" next="/account"
    fields={[
      { name: "email", label: "Email address", type: "email", autoComplete: "email", inputMode: "email" },
      { name: "password", label: "Password", type: "password", autoComplete: "current-password" }
    ]}
    footer={<><a href="/forgot">Forgot password?</a> · <a href="/signup">Create account</a></>} />;
}
