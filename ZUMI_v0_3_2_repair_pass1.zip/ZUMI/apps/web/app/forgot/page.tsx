import AuthForm from "../../components/AuthForm";
export default function Page() {
  return (
    <main id="main" className="shell">
      <AuthForm embedded title="Forgot password" path="/api/v1/auth/forgot" submitLabel="Email me a code" successMessage="If that email has an account, a 6-digit code is on its way. Enter it below."
        fields={[{ name: "email", label: "Email address", type: "email", autoComplete: "email", inputMode: "email" }]} />
      <AuthForm embedded title="Set a new password" path="/api/v1/auth/reset" submitLabel="Reset password" next="/login"
        fields={[
          { name: "email", label: "Email address", type: "email", autoComplete: "email", inputMode: "email" },
          { name: "code", label: "6-digit code", autoComplete: "one-time-code", inputMode: "numeric" },
          { name: "newPassword", label: "New password (10+ characters)", type: "password", autoComplete: "new-password" }
        ]} />
    </main>
  );
}
