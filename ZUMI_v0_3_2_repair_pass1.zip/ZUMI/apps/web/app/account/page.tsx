"use client";
import { useEffect, useState } from "react";
import { api } from "../../lib/api";

export default function Page() {
  const [state, setState] = useState<"loading" | "out" | { email: string }>("loading");
  useEffect(() => {
    api("/api/v1/auth/me", "GET").then((r) => setState(r.ok && r.data.user ? { email: r.data.user.email } : "out"));
  }, []);

  async function logout() {
    await api("/api/v1/auth/logout", "POST", {});
    window.location.assign("/login");
  }
  if (state === "loading") return <main id="main" className="shell"><p>Loading…</p></main>;
  if (state === "out") return <main id="main" className="shell"><p>You are not logged in. <a href="/login">Log in</a></p></main>;
  return (
    <main id="main" className="shell">
      <h1>Welcome to ZUMI</h1>
      <p>Signed in as {state.email}.</p>
      <p>Home feed, categories and Zumi AI are the next modules to build.</p>
      <button onClick={logout} className="secondary" style={{ padding: "12px 20px", fontSize: 16 }}>Log out</button>
    </main>
  );
}
