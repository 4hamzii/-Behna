import AuthForm from "../../components/AuthForm";
export default function Page() {
  return <AuthForm title="Create your account" path="/api/v1/auth/signup" submitLabel="Continue" next="/verify" carry={["email"]}
    fields={[
      { name: "displayName", label: "Full name", autoComplete: "name" },
      { name: "handle", label: "Username (letters, numbers, _)", autoComplete: "username" },
      { name: "email", label: "Gmail / email address", type: "email", autoComplete: "email", inputMode: "email" },
      { name: "password", label: "Password (10+ characters)", type: "password", autoComplete: "new-password" }
    ]}
    footer={<>Already have an account? <a href="/login">Log in</a></>} />;
}
