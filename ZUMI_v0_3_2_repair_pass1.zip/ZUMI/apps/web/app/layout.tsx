import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ZUMI",
  description: "A connected space for communication, creativity, learning and everyday life."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#main">Skip to main content</a>
        {children}
      </body>
    </html>
  );
}
