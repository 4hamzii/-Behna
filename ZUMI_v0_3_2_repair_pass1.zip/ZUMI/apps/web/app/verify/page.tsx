import AuthForm from "../../components/AuthForm";
export default async function Page({ searchParams }: { searchParams: Promise<{ email?: string }> }) {
  const { email = "" } = await searchParams;
  return <AuthForm title="Enter your 6-digit code" path="/api/v1/auth/verify-email" submitLabel="Verify" next="/login"
    fields={[
      { name: "email", label: "Email address", type: "email", autoComplete: "email", inputMode: "email", defaultValue: email },
      { name: "code", label: "6-digit code from your email", autoComplete: "one-time-code", inputMode: "numeric" }
    ]}
    footer={<>Codes last 10 minutes. No email yet? Check spam, then <a href="/signup">start again</a>.</>} />;
}
