export default function HomePage() {
  return (
    <main id="main" className="shell">
      <nav className="nav"><div className="brand">ZUMI<span>●</span></div><span className="status">Development preview</span></nav>
      <section className="hero">
        <p className="eyebrow">ONE CONNECTED SPACE</p>
        <h1>Make room for<br/><em>what matters.</em></h1>
        <p className="intro">Communication, creativity, learning and everyday life — brought together in one thoughtful space.</p>
        <div className="actions"><a href="/signup" className="primary">Create account</a><a href="/login" className="secondary">Log in</a></div>
      </section>
      <section id="modules" className="modules">
        <div><small>01 / CONNECT</small><h2>People & conversations</h2><p>Profiles, messaging, communities and shared moments.</p></div>
        <div><small>02 / CREATE</small><h2>Tools & expression</h2><p>Capture, studio, documents, files and personal spaces.</p></div>
        <div><small>03 / DISCOVER</small><h2>Knowledge & discovery</h2><p>Learning, search, AI-assisted workflows and exploration.</p></div>
      </section>
      <section id="about" className="foot"><b>Built step by step.</b><p>This is an early development foundation, not a public launch. Features are added, tested and approved module by module.</p></section>
      <footer>© {new Date().getFullYear()} ZUMI · Original product concept</footer>
    </main>
  );
}
