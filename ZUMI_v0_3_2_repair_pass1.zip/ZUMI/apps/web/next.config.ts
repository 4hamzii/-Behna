import type { NextConfig } from "next";
import { buildSecurityHeaders } from "./lib/securityHeaders";

const config: NextConfig = {
  poweredByHeader: false,
  // Linting runs from the repository root (pnpm lint).
  eslint: { ignoreDuringBuilds: true },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: buildSecurityHeaders({
          isProd: process.env.NODE_ENV === "production",
          apiUrl: process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000"
        })
      }
    ];
  }
};
export default config;
