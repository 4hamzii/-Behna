"use client";
import { useState, type FormEvent } from "react";
import { api } from "../lib/api";

export interface Field { name: string; label: string; type?: string; autoComplete?: string; inputMode?: "numeric" | "text" | "email"; defaultValue?: string }

interface Props {
  title: string;
  path: string;
  fields: Field[];
  submitLabel: string;
  /** Where to go after success (full page navigation keeps this component simple). Omit to stay and show successMessage. */
  next?: string;
  /** Shown in place of navigating when `next` is omitted. */
  successMessage?: string;
  /** Values to carry in the URL query to the next screen, e.g. ["email"]. */
  carry?: string[];
  footer?: React.ReactNode;
  /** true when the page already provides <main> (renders a section with an h2 instead). */
  embedded?: boolean;
}

export default function AuthForm({ title, path, fields, submitLabel, next, successMessage, carry = [], footer, embedded = false }: Props) {
  const [error, setError] = useState("");
  const [done, setDone] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setDone("");
    const form = new FormData(e.currentTarget);
    const body = Object.fromEntries(fields.map((f) => [f.name, String(form.get(f.name) ?? "")]));
    const res = await api(path, "POST", body);
    setBusy(false);
    if (!res.ok) {
      const first = res.data.issues?.[0];
      setError(res.data.message ?? (first ? first.message : "Something went wrong. Please try again."));
      return;
    }
    if (!next) {
      setDone(successMessage ?? "Done.");
      return;
    }
    const q = new URLSearchParams(carry.map((k) => [k, body[k] ?? ""]));
    window.location.assign(carry.length > 0 ? `${next}?${q}` : next);
  }

  const Wrapper = embedded ? "section" : "main";
  const Heading = embedded ? "h2" : "h1";
  return (
    <Wrapper {...(embedded ? { "aria-label": title } : { id: "main" })} className={embedded ? undefined : "shell"} style={{ maxWidth: 420 }}>
      <Heading>{title}</Heading>
      <form onSubmit={onSubmit} noValidate>
        {fields.map((f) => (
          <p key={f.name}>
            <label htmlFor={f.name}>{f.label}</label><br />
            <input id={f.name} name={f.name} type={f.type ?? "text"} required autoComplete={f.autoComplete}
              inputMode={f.inputMode} defaultValue={f.defaultValue} style={{ width: "100%", padding: 12, fontSize: 16 }} />
          </p>
        ))}
        <p role="alert" aria-live="polite" style={{ color: "#b00020", minHeight: "1.5em" }}>{error}</p>
        {done && <p role="status" style={{ color: "#116329" }}>{done}</p>}
        <button type="submit" disabled={busy} className="primary" style={{ padding: "12px 20px", fontSize: 16 }}>
          {busy ? "Please wait…" : submitLabel}
        </button>
      </form>
      <p>{footer}</p>
    </Wrapper>
  );
}
