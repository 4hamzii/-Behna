export type Purpose = "EMAIL_VERIFY" | "PASSWORD_RESET";
export type Status = "PENDING" | "ACTIVE" | "SUSPENDED" | "DELETION_PENDING" | "DELETED";

export interface StoredUser {
  id: string;
  email: string;
  status: Status;
  passwordHash: string | null;
}
export interface OpenVerification { id: string; codeHash: string; attempts: number }
export interface StoredSession { id: string; expiresAt: Date; revokedAt: Date | null; lastUsedAt: Date; user: StoredUser }

export class HandleTakenError extends Error {
  constructor() { super("HANDLE_TAKEN"); }
}
export class EmailTakenError extends Error {
  constructor() { super("EMAIL_TAKEN"); }
}

/** Everything the auth routes need from a database. Prisma implements it; tests use memory. */
export interface AuthStore {
  findUserByEmail(email: string): Promise<StoredUser | null>;
  createUser(input: { email: string; handle: string; displayName: string; passwordHash: string }): Promise<StoredUser>;
  activateUser(userId: string): Promise<void>;
  setPassword(userId: string, passwordHash: string): Promise<void>;
  replaceVerification(userId: string, purpose: Purpose, codeHash: string, expiresAt: Date): Promise<void>;
  getOpenVerification(userId: string, purpose: Purpose): Promise<OpenVerification | null>;
  /** Atomically use up one guess. Returns false (and changes nothing) if `max` guesses were already used or the code is consumed. */
  claimAttempt(id: string, max: number): Promise<boolean>;
  /** Atomically mark the code used. Returns true only for the single caller that actually consumed it. */
  consumeVerification(id: string): Promise<boolean>;
  createSession(userId: string, tokenHash: string, expiresAt: Date): Promise<void>;
  getSession(tokenHash: string): Promise<StoredSession | null>;
  revokeSession(tokenHash: string): Promise<void>;
  revokeAllSessions(userId: string): Promise<void>;
  touchSession(sessionId: string): Promise<void>;
  /** Housekeeping: remove long-dead sessions, old codes and old audit rows. */
  purgeExpired(now: Date): Promise<void>;
  audit(action: string, actorId: string | null): Promise<void>;
}

export interface Mailer {
  send(to: string, subject: string, text: string): Promise<void>;
}
