import { afterEach, describe, expect, it } from "vitest";
import type { FastifyInstance } from "fastify";
import { buildApp } from "../app.js";
import { EmailTakenError, HandleTakenError, type AuthStore, type Mailer, type StoredSession, type StoredUser } from "./store.js";

const SECRET = "test-secret-".repeat(4);
const ORIGIN = "http://localhost:3000";

function memoryStore(): AuthStore {
  const users: StoredUser[] = [];
  const handles = new Set<string>();
  const codes: { id: string; userId: string; purpose: string; codeHash: string; attempts: number; used: boolean; expiresAt: Date }[] = [];
  const sessions = new Map<string, { id: string; userId: string; expiresAt: Date; revokedAt: Date | null; lastUsedAt: Date }>();
  let n = 0;
  const find = (id: string) => users.find((u) => u.id === id) as StoredUser;
  return {
    async findUserByEmail(email) { return users.find((u) => u.email === email) ?? null; },
    async createUser(i) {
      if (users.some((u) => u.email === i.email)) throw new EmailTakenError();
      if (handles.has(i.handle.toLowerCase())) throw new HandleTakenError();
      handles.add(i.handle.toLowerCase());
      const u: StoredUser = { id: `u${++n}`, email: i.email, status: "PENDING", passwordHash: i.passwordHash };
      users.push(u);
      return u;
    },
    async activateUser(id) { find(id).status = "ACTIVE"; },
    async setPassword(id, h) { find(id).passwordHash = h; },
    async replaceVerification(userId, purpose, codeHash, expiresAt) {
      for (let i = codes.length - 1; i >= 0; i--) if (codes[i]?.userId === userId && codes[i]?.purpose === purpose) codes.splice(i, 1);
      codes.push({ id: `c${++n}`, userId, purpose, codeHash, attempts: 0, used: false, expiresAt });
    },
    async getOpenVerification(userId, purpose) {
      const c = codes.find((x) => x.userId === userId && x.purpose === purpose && !x.used && x.expiresAt > new Date());
      return c ? { id: c.id, codeHash: c.codeHash, attempts: c.attempts } : null;
    },
    async claimAttempt(id, max) {
      const c = codes.find((x) => x.id === id);
      if (!c || c.used || c.attempts >= max) return false;
      c.attempts++;
      return true;
    },
    async consumeVerification(id) {
      const c = codes.find((x) => x.id === id);
      if (!c || c.used) return false;
      c.used = true;
      return true;
    },
    async createSession(userId, tokenHash, expiresAt) { sessions.set(tokenHash, { id: `s${++n}`, userId, expiresAt, revokedAt: null, lastUsedAt: new Date() }); },
    async getSession(tokenHash): Promise<StoredSession | null> {
      const s = sessions.get(tokenHash);
      return s ? { id: s.id, expiresAt: s.expiresAt, revokedAt: s.revokedAt, lastUsedAt: s.lastUsedAt, user: find(s.userId) } : null;
    },
    async revokeSession(h) { const s = sessions.get(h); if (s) s.revokedAt = new Date(); },
    async revokeAllSessions(userId) { for (const s of sessions.values()) if (s.userId === userId) s.revokedAt = new Date(); },
    async touchSession(id) { for (const s of sessions.values()) if (s.id === id) s.lastUsedAt = new Date(); },
    async purgeExpired() { /* covered by Prisma integration test later */ },
    async audit() { /* not needed in tests */ }
  };
}

let app: FastifyInstance | undefined;
afterEach(async () => { await app?.close(); app = undefined; });

async function setup(store: AuthStore = memoryStore()) {
  const sent: { to: string; text: string }[] = [];
  const mailer: Mailer = { async send(to, _s, text) { sent.push({ to, text }); } };
  app = await buildApp({ logger: false, corsOrigin: ORIGIN, rateLimitMax: 1000, auth: { store, mailer, secret: SECRET, secureCookie: false } });
  const lastCode = () => /\b(\d{6})\b/.exec(sent.at(-1)?.text ?? "")?.[1] ?? "";
  const post = (url: string, payload: unknown, cookies?: Record<string, string>) =>
    app!.inject({ method: "POST", url, payload: payload as object, headers: { origin: ORIGIN }, ...(cookies ? { cookies } : {}) });
  return { sent, lastCode, post };
}
const SIGNUP = { email: "sam@example.com", password: "plum-lantern-orbit-77", handle: "sam_1", displayName: "Sam" };

describe("auth flow", () => {
  it("signup -> verify -> login -> me -> logout", async () => {
    const { lastCode, post } = await setup();
    expect((await post("/api/v1/auth/signup", SIGNUP)).statusCode).toBe(202);
    expect((await post("/api/v1/auth/login", SIGNUP)).statusCode).toBe(403); // not verified yet
    expect((await post("/api/v1/auth/verify-email", { email: SIGNUP.email, code: lastCode() })).statusCode).toBe(200);

    const login = await post("/api/v1/auth/login", { email: SIGNUP.email, password: SIGNUP.password });
    expect(login.statusCode).toBe(200);
    const cookie = login.cookies[0];
    expect(cookie?.httpOnly).toBe(true);
    const jar = { zumi_session: cookie?.value ?? "" };

    expect((await app!.inject({ method: "GET", url: "/api/v1/auth/me", cookies: jar })).statusCode).toBe(200);
    expect((await post("/api/v1/auth/logout", {}, jar)).statusCode).toBe(204);
    expect((await app!.inject({ method: "GET", url: "/api/v1/auth/me", cookies: jar })).statusCode).toBe(401);
  });

  it("gives the same answer for a new and an existing email (no enumeration)", async () => {
    const { post, sent } = await setup();
    const a = await post("/api/v1/auth/signup", SIGNUP);
    const b = await post("/api/v1/auth/signup", { ...SIGNUP, handle: "other_1" });
    expect(b.statusCode).toBe(a.statusCode);
    expect(b.json()).toEqual(a.json());
    expect(sent).toHaveLength(2); // the owner of the existing email is warned, and gets no code
    expect(sent[1]?.text).not.toMatch(/\b\d{6}\b/);
  });

  it("uses one error for wrong password and unknown email", async () => {
    const { lastCode, post } = await setup();
    await post("/api/v1/auth/signup", SIGNUP);
    await post("/api/v1/auth/verify-email", { email: SIGNUP.email, code: lastCode() });
    const wrong = await post("/api/v1/auth/login", { email: SIGNUP.email, password: "not-the-password-1" });
    const none = await post("/api/v1/auth/login", { email: "nobody@example.com", password: "not-the-password-1" });
    expect(wrong.statusCode).toBe(401);
    expect(none.json()).toEqual(wrong.json());
  });

  it("locks a code after 5 wrong guesses, even if the right code follows", async () => {
    const { lastCode, post } = await setup();
    await post("/api/v1/auth/signup", SIGNUP);
    const right = lastCode();
    const wrong = right === "000000" ? "111111" : "000000";
    for (let i = 0; i < 5; i++) expect((await post("/api/v1/auth/verify-email", { email: SIGNUP.email, code: wrong })).statusCode).toBe(400);
    expect((await post("/api/v1/auth/verify-email", { email: SIGNUP.email, code: right })).statusCode).toBe(400);
  });

  it("password reset works once and logs out other sessions", async () => {
    const { lastCode, post } = await setup();
    await post("/api/v1/auth/signup", SIGNUP);
    await post("/api/v1/auth/verify-email", { email: SIGNUP.email, code: lastCode() });
    const login = await post("/api/v1/auth/login", { email: SIGNUP.email, password: SIGNUP.password });
    const jar = { zumi_session: login.cookies[0]?.value ?? "" };

    await post("/api/v1/auth/forgot", { email: SIGNUP.email });
    const code = lastCode();
    const reset = { email: SIGNUP.email, code, newPassword: "fresh-maple-comet-99" };
    expect((await post("/api/v1/auth/reset", reset)).statusCode).toBe(200);
    expect((await post("/api/v1/auth/reset", reset)).statusCode).toBe(400); // code is single-use
    expect((await app!.inject({ method: "GET", url: "/api/v1/auth/me", cookies: jar })).statusCode).toBe(401);
    expect((await post("/api/v1/auth/login", { email: SIGNUP.email, password: "fresh-maple-comet-99" })).statusCode).toBe(200);
  });

  it("rejects weak passwords and foreign origins", async () => {
    const { post } = await setup();
    expect((await post("/api/v1/auth/signup", { ...SIGNUP, password: "password123" })).statusCode).toBe(400);
    const evil = await app!.inject({ method: "POST", url: "/api/v1/auth/login", payload: { email: "a@b.com", password: "x" }, headers: { origin: "https://evil.example" } });
    expect(evil.statusCode).toBe(403);
  });

  it("allows only 5 guesses even when 30 arrive at the same time", async () => {
    const inner = memoryStore();
    let granted = 0;
    const store: AuthStore = { ...inner, async claimAttempt(id, max) { const ok = await inner.claimAttempt(id, max); if (ok) granted++; return ok; } };
    const { lastCode, post } = await setup(store);
    await post("/api/v1/auth/signup", SIGNUP);
    const wrong = lastCode() === "000000" ? "111111" : "000000";
    // Each request comes from a different IP (a distributed attacker), so the per-IP rate limit does not
    // hide the bug: only the atomic attempt counter stands between these guesses and the code.
    const results = await Promise.all(Array.from({ length: 30 }, (_, i) =>
      app!.inject({ method: "POST", url: "/api/v1/auth/verify-email", payload: { email: SIGNUP.email, code: wrong }, headers: { origin: ORIGIN }, remoteAddress: `10.0.0.${i + 1}` })));
    expect(results.every((r) => r.statusCode === 400)).toBe(true);
    expect(granted).toBe(5);
  });

  it("a reset code works only once even when submitted twice at the same time", async () => {
    const { lastCode, post } = await setup();
    await post("/api/v1/auth/signup", SIGNUP);
    await post("/api/v1/auth/verify-email", { email: SIGNUP.email, code: lastCode() });
    await post("/api/v1/auth/forgot", { email: SIGNUP.email });
    const body = { email: SIGNUP.email, code: lastCode(), newPassword: "fresh-maple-comet-99" };
    const both = await Promise.all([post("/api/v1/auth/reset", body), post("/api/v1/auth/reset", body)]);
    expect(both.map((r) => r.statusCode).sort()).toEqual([200, 400]);
  });
});
