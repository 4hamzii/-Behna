import { Prisma, type PrismaClient } from "@prisma/client";
import { EmailTakenError, HandleTakenError, type AuthStore, type StoredUser } from "./store.js";

type UserRow = { id: string; email: string | null; status: StoredUser["status"]; credentials: { secretHash: string | null }[] };

function toUser(row: UserRow): StoredUser {
  return { id: row.id, email: row.email ?? "", status: row.status, passwordHash: row.credentials[0]?.secretHash ?? null };
}
const withPassword = { credentials: { where: { type: "PASSWORD" as const, revokedAt: null }, select: { secretHash: true }, take: 1 } };

export function createPrismaStore(db: PrismaClient): AuthStore {
  return {
    async findUserByEmail(email) {
      const row = await db.user.findUnique({ where: { email }, include: withPassword });
      return row ? toUser(row) : null;
    },

    async createUser({ email, handle, displayName, passwordHash }) {
      try {
        const row = await db.user.create({
          data: {
            email,
            status: "PENDING",
            profile: { create: { handle, handleLower: handle.toLowerCase(), displayName } },
            privacySettings: { create: {} },
            credentials: { create: { type: "PASSWORD", secretHash: passwordHash } }
          },
          include: withPassword
        });
        return toUser(row);
      } catch (error) {
        if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
          const target = String(error.meta?.target ?? "");
          throw target.includes("handleLower") ? new HandleTakenError() : new EmailTakenError();
        }
        throw error;
      }
    },

    async activateUser(userId) {
      await db.user.update({ where: { id: userId }, data: { status: "ACTIVE" } });
    },

    async setPassword(userId, passwordHash) {
      await db.$transaction([
        db.credential.updateMany({ where: { userId, type: "PASSWORD", revokedAt: null }, data: { revokedAt: new Date() } }),
        db.credential.create({ data: { userId, type: "PASSWORD", secretHash: passwordHash } })
      ]);
    },

    async replaceVerification(userId, purpose, codeHash, expiresAt) {
      await db.$transaction([
        db.verificationToken.deleteMany({ where: { userId, purpose } }),
        db.verificationToken.create({ data: { userId, purpose, tokenHash: codeHash, expiresAt } })
      ]);
    },

    async getOpenVerification(userId, purpose) {
      const row = await db.verificationToken.findFirst({
        where: { userId, purpose, consumedAt: null, expiresAt: { gt: new Date() } },
        orderBy: { createdAt: "desc" }
      });
      return row ? { id: row.id, codeHash: row.tokenHash, attempts: row.attempts } : null;
    },

    async claimAttempt(id, max) {
      // One conditional UPDATE: PostgreSQL re-checks "attempts < max" under a row lock, so concurrent
      // requests cannot exceed the limit.
      const r = await db.verificationToken.updateMany({ where: { id, consumedAt: null, attempts: { lt: max } }, data: { attempts: { increment: 1 } } });
      return r.count === 1;
    },

    async consumeVerification(id) {
      const r = await db.verificationToken.updateMany({ where: { id, consumedAt: null }, data: { consumedAt: new Date() } });
      return r.count === 1;
    },

    async createSession(userId, tokenHash, expiresAt) {
      await db.session.create({ data: { userId, tokenHash, expiresAt } });
    },

    async getSession(tokenHash) {
      const row = await db.session.findUnique({ where: { tokenHash }, include: { user: { include: withPassword } } });
      return row ? { id: row.id, expiresAt: row.expiresAt, revokedAt: row.revokedAt, lastUsedAt: row.lastUsedAt, user: toUser(row.user) } : null;
    },

    async revokeSession(tokenHash) {
      await db.session.updateMany({ where: { tokenHash, revokedAt: null }, data: { revokedAt: new Date() } });
    },

    async revokeAllSessions(userId) {
      await db.session.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
    },

    async touchSession(sessionId) {
      await db.session.update({ where: { id: sessionId }, data: { lastUsedAt: new Date() } });
    },

    async purgeExpired(now) {
      const day = 24 * 60 * 60 * 1000;
      const weekAgo = new Date(now.getTime() - 7 * day);
      await db.session.deleteMany({ where: { OR: [{ expiresAt: { lt: weekAgo } }, { revokedAt: { lt: weekAgo } }] } });
      await db.verificationToken.deleteMany({ where: { expiresAt: { lt: new Date(now.getTime() - day) } } });
      await db.auditEvent.deleteMany({ where: { createdAt: { lt: new Date(now.getTime() - 180 * day) } } });
    },

    async audit(action, actorId) {
      await db.auditEvent.create({ data: { action, actorId } });
    }
  };
}
