import { describe, expect, it } from "vitest";
import { DUMMY_HASH, hashCode, hashPassword, hashToken, isWeakPassword, newCode, newSessionToken, safeEqualHex, verifyPassword } from "./crypto.js";

describe("password hashing", () => {
  it("verifies the right password and rejects the wrong one", async () => {
    const h = await hashPassword("correct horse battery");
    expect(h.startsWith("scrypt$")).toBe(true);
    expect(await verifyPassword("correct horse battery", h)).toBe(true);
    expect(await verifyPassword("wrong horse battery", h)).toBe(false);
  });
  it("uses a different salt every time", async () => {
    expect(await hashPassword("same-password-1")).not.toBe(await hashPassword("same-password-1"));
  });
  it("rejects malformed stored hashes instead of throwing", async () => {
    expect(await verifyPassword("x", "not-a-hash")).toBe(false);
  });
  it("still accepts hashes made by the previous synchronous implementation (same stored format)", async () => {
    // Generated with the v0.3.1 scryptSync code: same "scrypt$N$r$p$salt$hash" layout.
    const legacy = DUMMY_HASH;
    expect(legacy.split("$")).toHaveLength(6);
    expect(await verifyPassword("definitely-not-it", legacy)).toBe(false);
  });
  it("hands control back immediately instead of freezing the server while hashing", async () => {
    const t0 = performance.now();
    const pending = hashPassword("a-long-enough-password");
    const returnedAfter = performance.now() - t0;
    await pending;
    const total = performance.now() - t0;
    // Synchronous scrypt would make returnedAfter ~= total (the whole hash happens before returning).
    expect(returnedAfter).toBeLessThan(total / 4);
  });
});

describe("weak password check", () => {
  it("flags common, repeated and email-derived passwords", () => {
    expect(isWeakPassword("password123")).toBe(true);
    expect(isWeakPassword("aaaaaaaaaaaa")).toBe(true);
    expect(isWeakPassword("sammyjones2026", "sammyjones@x.com")).toBe(true);
    expect(isWeakPassword("plum-lantern-orbit-77", "sam@x.com")).toBe(false);
  });
});

describe("tokens and codes", () => {
  it("makes 6-digit codes and long unique session tokens", () => {
    for (let i = 0; i < 200; i++) expect(newCode()).toMatch(/^\d{6}$/);
    expect(newSessionToken()).not.toBe(newSessionToken());
    expect(newSessionToken().length).toBeGreaterThanOrEqual(43);
  });
  it("hashes deterministically and compares safely", () => {
    expect(hashToken("abc")).toBe(hashToken("abc"));
    const a = hashCode("s".repeat(32), "u1", "EMAIL_VERIFY", "123456");
    expect(safeEqualHex(a, hashCode("s".repeat(32), "u1", "EMAIL_VERIFY", "123456"))).toBe(true);
    expect(safeEqualHex(a, hashCode("s".repeat(32), "u2", "EMAIL_VERIFY", "123456"))).toBe(false);
    expect(safeEqualHex(a, "00")).toBe(false);
  });
});
