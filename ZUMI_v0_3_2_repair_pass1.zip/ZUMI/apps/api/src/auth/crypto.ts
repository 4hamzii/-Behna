import { createHash, createHmac, randomBytes, randomInt, scrypt, scryptSync, timingSafeEqual, type ScryptOptions } from "node:crypto";
import { promisify } from "node:util";

// Async scrypt runs on libuv's thread pool, so hashing a password does not freeze the whole server
// (the old scryptSync blocked every other request for ~75 ms per login/signup).
const scryptAsync = promisify(scrypt) as (password: string, salt: Buffer, keylen: number, options: ScryptOptions) => Promise<Buffer>;

// scrypt parameters (OWASP-recommended minimum: N=2^17 for interactive; 2^15 keeps CI/Codespaces fast).
// Raise N in production after measuring login latency on your host.
const N = 32768;
const R = 8;
const P = 1;
const KEYLEN = 64;
const MAXMEM = 128 * N * R * 2;

function encode(salt: Buffer, hash: Buffer): string {
  return `scrypt$${N}$${R}$${P}$${salt.toString("base64")}$${hash.toString("base64")}`;
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = await scryptAsync(password.normalize("NFKC"), salt, KEYLEN, { N, r: R, p: P, maxmem: MAXMEM });
  return encode(salt, hash);
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, r, p, saltB64, hashB64] = parts as [string, string, string, string, string, string];
  const expected = Buffer.from(hashB64, "base64");
  const actual = await scryptAsync(password.normalize("NFKC"), Buffer.from(saltB64, "base64"), expected.length, {
    N: Number(n), r: Number(r), p: Number(p), maxmem: 128 * Number(n) * Number(r) * 2
  });
  return timingSafeEqual(actual, expected);
}

/** A real hash of a random value, used to keep login timing the same when the email does not exist. */
// Computed once at startup (a single ~75 ms synchronous call before the server accepts requests).
export const DUMMY_HASH = (() => {
  const salt = randomBytes(16);
  return encode(salt, scryptSync(randomBytes(16).toString("hex"), salt, KEYLEN, { N, r: R, p: P, maxmem: MAXMEM }));
})();

const COMMON = new Set(["password123", "1234567890", "qwertyuiop", "letmein123", "iloveyou123", "admin12345"]);
export function isWeakPassword(password: string, email?: string): boolean {
  const lower = password.toLowerCase();
  if (COMMON.has(lower)) return true;
  if (/^(.)\1+$/.test(password)) return true;
  const local = email?.split("@")[0]?.toLowerCase();
  return Boolean(local && local.length >= 4 && lower.includes(local));
}

/** Opaque session token (sent to the browser) and its SHA-256 hash (stored in the database). */
export const newSessionToken = (): string => randomBytes(32).toString("base64url");
export const hashToken = (token: string): string => createHash("sha256").update(token).digest("hex");

/** Six-digit one-time code from a cryptographically secure generator. */
export const newCode = (): string => randomInt(0, 1_000_000).toString().padStart(6, "0");

/** Keyed hash so a stolen database cannot be used to brute-force the 6-digit codes without AUTH_SECRET. */
export function hashCode(secret: string, userId: string, purpose: string, code: string): string {
  return createHmac("sha256", secret).update(`${userId}:${purpose}:${code}`).digest("hex");
}

export function safeEqualHex(a: string, b: string): boolean {
  const x = Buffer.from(a, "hex");
  const y = Buffer.from(b, "hex");
  return x.length === y.length && timingSafeEqual(x, y);
}
