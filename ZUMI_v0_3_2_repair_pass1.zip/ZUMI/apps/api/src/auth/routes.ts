import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import {
  EmailOnlySchema, LoginSchema, ResetPasswordSchema, SignupSchema, VerifyEmailSchema
} from "@zumi/shared";
import { parseBody } from "../validate.js";
import {
  DUMMY_HASH, hashCode, hashPassword, hashToken, isWeakPassword, newCode, newSessionToken, safeEqualHex, verifyPassword
} from "./crypto.js";
import { EmailTakenError, HandleTakenError, type AuthStore, type Mailer, type Purpose, type StoredUser } from "./store.js";

export interface AuthOptions {
  store: AuthStore;
  mailer: Mailer;
  /** Secret used to key the hash of one-time codes. Must be long and random in production. */
  secret: string;
  /** Exact allowed browser origins (same list as CORS). */
  allowedOrigins: string[];
  /** true in production so the cookie is only sent over HTTPS. */
  secureCookie: boolean;
}

export const SESSION_COOKIE = "zumi_session";
const CODE_TTL_MS = 10 * 60 * 1000;
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_CODE_ATTEMPTS = 5;
const IDLE_LIMIT_MS = 14 * 24 * 60 * 60 * 1000; // log out after 14 days without use
const TOUCH_EVERY_MS = 60 * 60 * 1000; // record activity at most once an hour
const GENERIC = { ok: true, message: "If that request can be completed, an email has been sent." };

declare module "fastify" {
  interface FastifyRequest { authUser?: StoredUser }
}

export function registerAuthRoutes(app: FastifyInstance, opts: AuthOptions): void {
  const { store, mailer, secret } = opts;

  async function sendCode(user: StoredUser, purpose: Purpose): Promise<void> {
    const code = newCode();
    await store.replaceVerification(user.id, purpose, hashCode(secret, user.id, purpose, code), new Date(Date.now() + CODE_TTL_MS));
    const subject = purpose === "EMAIL_VERIFY" ? "Verify your ZUMI account" : "Reset your ZUMI password";
    await mailer.send(user.email, subject, `Your ZUMI code is ${code}. It expires in 10 minutes. If you did not ask for it, ignore this email.`);
  }

  async function checkCode(user: StoredUser, purpose: Purpose, code: string): Promise<boolean> {
    const open = await store.getOpenVerification(user.id, purpose);
    if (!open) return false;
    // Claim one of the MAX_CODE_ATTEMPTS guesses BEFORE comparing. The claim is one atomic database
    // operation, so parallel requests cannot all read "0 attempts used" and each get a free guess.
    if (!(await store.claimAttempt(open.id, MAX_CODE_ATTEMPTS))) return false;
    if (!safeEqualHex(open.codeHash, hashCode(secret, user.id, purpose, code))) return false;
    // Only the first correct request can consume the code, so a code is strictly single-use.
    return store.consumeVerification(open.id);
  }

  async function startSession(user: StoredUser, reply: FastifyReply): Promise<void> {
    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
    await store.createSession(user.id, hashToken(token), expiresAt);
    reply.setCookie(SESSION_COOKIE, token, {
      httpOnly: true, secure: opts.secureCookie, sameSite: "lax", path: "/", expires: expiresAt
    });
  }

  /** Use as a preHandler on any private route. Sets request.authUser. */
  async function requireAuth(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | void> {
    const token = request.cookies[SESSION_COOKIE];
    const session = token ? await store.getSession(hashToken(token)) : null;
    const now = Date.now();
    if (
      !session || session.revokedAt || session.expiresAt.getTime() <= now ||
      now - session.lastUsedAt.getTime() > IDLE_LIMIT_MS || session.user.status !== "ACTIVE"
    ) {
      return reply.code(401).send({ error: "UNAUTHENTICATED", message: "Please log in." });
    }
    if (now - session.lastUsedAt.getTime() > TOUCH_EVERY_MS) await store.touchSession(session.id);
    request.authUser = session.user;
  }
  app.decorate("requireAuth", requireAuth);

  // CSRF defence: browsers always send Origin on cross-site POSTs. Reject any that is not ours.
  app.addHook("preHandler", async (request, reply) => {
    if (request.method === "GET" || request.method === "HEAD" || request.method === "OPTIONS") return;
    const origin = request.headers.origin;
    if (origin && !opts.allowedOrigins.includes(origin)) {
      return reply.code(403).send({ error: "BAD_ORIGIN", message: "Request origin not allowed." });
    }
  });

  const limit = (max: number, timeWindow: string) => ({ config: { rateLimit: { max, timeWindow } } });

  app.post("/api/v1/auth/signup", limit(5, "1 hour"), async (request, reply) => {
    const body = parseBody(SignupSchema, request.body);
    if (isWeakPassword(body.password, body.email)) {
      return reply.code(400).send({ error: "WEAK_PASSWORD", message: "Choose a less guessable password." });
    }
    const passwordHash = await hashPassword(body.password);
    try {
      const user = await store.createUser({ email: body.email, handle: body.handle, displayName: body.displayName, passwordHash });
      await sendCode(user, "EMAIL_VERIFY");
      await store.audit("auth.signup", user.id);
    } catch (error) {
      if (error instanceof HandleTakenError) return reply.code(409).send({ error: "HANDLE_TAKEN", message: "That handle is taken." });
      if (!(error instanceof EmailTakenError)) throw error;
      // Existing email: answer exactly like success so attackers cannot learn who has an account.
      // Also email the real owner (same work as the success path, which keeps timing similar and warns them).
      await mailer.send(body.email, "Someone tried to sign up with your email", "Someone tried to create a ZUMI account with this email. If it was you, log in or use Forgot password. If not, you can ignore this message.");
    }
    return reply.code(202).send(GENERIC);
  });

  app.post("/api/v1/auth/verify-email", limit(10, "15 minutes"), async (request, reply) => {
    const { email, code } = parseBody(VerifyEmailSchema, request.body);
    const user = await store.findUserByEmail(email);
    if (!user || user.status !== "PENDING" || !(await checkCode(user, "EMAIL_VERIFY", code))) {
      return reply.code(400).send({ error: "INVALID_CODE", message: "Incorrect or expired code." });
    }
    await store.activateUser(user.id);
    await store.audit("auth.email_verified", user.id);
    return { ok: true };
  });

  app.post("/api/v1/auth/resend", limit(3, "1 hour"), async (request, reply) => {
    const { email } = parseBody(EmailOnlySchema, request.body);
    const user = await store.findUserByEmail(email);
    if (user?.status === "PENDING") await sendCode(user, "EMAIL_VERIFY");
    return reply.code(202).send(GENERIC);
  });

  app.post("/api/v1/auth/login", limit(10, "15 minutes"), async (request, reply) => {
    const { email, password } = parseBody(LoginSchema, request.body);
    const user = await store.findUserByEmail(email);
    // Always do one password check so response time does not reveal whether the email exists.
    const passwordOk = await verifyPassword(password, user?.passwordHash ?? DUMMY_HASH);
    if (!user || !passwordOk) {
      await store.audit("auth.login_failed", user?.id ?? null);
      return reply.code(401).send({ error: "BAD_CREDENTIALS", message: "Email or password is incorrect." });
    }
    if (user.status === "PENDING") return reply.code(403).send({ error: "EMAIL_NOT_VERIFIED", message: "Verify your email first." });
    if (user.status !== "ACTIVE") return reply.code(403).send({ error: "ACCOUNT_UNAVAILABLE", message: "This account cannot log in." });
    await startSession(user, reply);
    await store.audit("auth.login", user.id);
    return { user: { id: user.id, email: user.email } };
  });

  app.post("/api/v1/auth/logout", async (request, reply) => {
    const token = request.cookies[SESSION_COOKIE];
    if (token) await store.revokeSession(hashToken(token));
    reply.clearCookie(SESSION_COOKIE, { path: "/" });
    return reply.code(204).send();
  });

  app.post("/api/v1/auth/forgot", limit(3, "1 hour"), async (request, reply) => {
    const { email } = parseBody(EmailOnlySchema, request.body);
    const user = await store.findUserByEmail(email);
    if (user?.status === "ACTIVE") await sendCode(user, "PASSWORD_RESET");
    return reply.code(202).send(GENERIC);
  });

  app.post("/api/v1/auth/reset", limit(10, "15 minutes"), async (request, reply) => {
    const { email, code, newPassword } = parseBody(ResetPasswordSchema, request.body);
    if (isWeakPassword(newPassword, email)) {
      return reply.code(400).send({ error: "WEAK_PASSWORD", message: "Choose a less guessable password." });
    }
    const user = await store.findUserByEmail(email);
    if (!user || user.status !== "ACTIVE" || !(await checkCode(user, "PASSWORD_RESET", code))) {
      return reply.code(400).send({ error: "INVALID_CODE", message: "Incorrect or expired code." });
    }
    await store.setPassword(user.id, await hashPassword(newPassword));
    await store.revokeAllSessions(user.id); // log out every device
    await store.audit("auth.password_reset", user.id);
    return { ok: true };
  });

  app.get("/api/v1/auth/me", { preHandler: requireAuth }, async (request) => ({
    user: { id: request.authUser?.id, email: request.authUser?.email }
  }));
}

declare module "fastify" {
  interface FastifyInstance {
    requireAuth: (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | void>;
  }
}
