import type { Mailer } from "./store.js";

/** Development mailer: prints the message to the API log instead of sending it. Never use in production. */
export const consoleMailer: Mailer = {
  async send(to, subject, text) {
    console.log(`[DEV MAIL] to=${to} subject="${subject}"\n${text}`);
  }
};

/** Production mailer using the Resend HTTP API (free tier). Needs RESEND_API_KEY and MAIL_FROM. */
export function resendMailer(apiKey: string, from: string): Mailer {
  return {
    async send(to, subject, text) {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from, to, subject, text })
      });
      if (!res.ok) throw new Error(`Mail provider returned ${res.status}`);
    }
  };
}
