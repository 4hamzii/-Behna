import { describe, expect, it } from "vitest";
import { parseTrustProxy } from "./config.js";

describe("parseTrustProxy", () => {
  it("trusts nothing by default", () => {
    expect(parseTrustProxy(undefined)).toBe(false);
    expect(parseTrustProxy("")).toBe(false);
    expect(parseTrustProxy("false")).toBe(false);
  });
  it("accepts specific IPs and CIDRs", () => {
    expect(parseTrustProxy("10.0.0.0/8, 127.0.0.1")).toEqual(["10.0.0.0/8", "127.0.0.1"]);
    expect(parseTrustProxy("::1")).toEqual(["::1"]);
  });
  it("rejects trust-everything values and garbage", () => {
    for (const bad of ["*", "true", "all", "0.0.0.0/0", "::/0", "not-an-ip", "10.0.0.1;rm"]) {
      expect(() => parseTrustProxy(bad)).toThrow();
    }
  });
});
