/**
 * Parse and validate the CORS_ORIGIN setting.
 * Accepts a comma-separated list of exact origins (scheme://host[:port]).
 * Rejects "*", paths, trailing slashes and non-http(s) schemes.
 * Empty/undefined means "no cross-origin access".
 */
export function parseCorsOrigins(raw: string | undefined): string[] {
  if (!raw) return [];
  const origins = raw.split(",").map((s) => s.trim()).filter((s) => s.length > 0);
  for (const origin of origins) {
    if (origin === "*") throw new Error("CORS_ORIGIN must not be '*'. List exact origins.");
    let url: URL;
    try {
      url = new URL(origin);
    } catch {
      throw new Error(`CORS_ORIGIN contains an invalid origin: ${origin}`);
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      throw new Error(`CORS_ORIGIN origin must use http or https: ${origin}`);
    }
    if (url.origin !== origin) {
      throw new Error(`CORS_ORIGIN must be an exact origin without path or trailing slash: ${origin}`);
    }
  }
  return origins;
}

/**
 * Parse TRUST_PROXY: a comma-separated list of proxy IPs/CIDRs whose X-Forwarded-* headers may be trusted
 * (e.g. "10.0.0.0/8,127.0.0.1"). Empty/undefined means "trust no proxy" (the safe default).
 * Fastify 5 no longer supports hop counts because they let direct clients spoof their IP.
 * "true" / "*" / "all" are rejected: trusting every sender defeats per-IP rate limiting.
 */
export function parseTrustProxy(raw: string | undefined): string[] | false {
  if (!raw || raw.trim() === "" || raw.trim().toLowerCase() === "false") return false;
  const entries = raw.split(",").map((s) => s.trim()).filter((s) => s.length > 0);
  for (const entry of entries) {
    if (["*", "true", "all", "0.0.0.0/0", "::/0"].includes(entry.toLowerCase())) {
      throw new Error("TRUST_PROXY must list specific proxy IPs/CIDRs, not everything.");
    }
    if (!/^[0-9a-fA-F:.]+(\/\d{1,3})?$/.test(entry)) {
      throw new Error(`TRUST_PROXY contains an invalid IP/CIDR: ${entry}`);
    }
  }
  return entries;
}
