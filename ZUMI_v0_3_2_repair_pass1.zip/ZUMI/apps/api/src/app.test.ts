import { afterEach, describe, expect, it } from "vitest";
import type { FastifyInstance } from "fastify";
import { CreatePostSchema } from "@zumi/shared";
import { buildApp } from "./app.js";
import { parseCorsOrigins } from "./config.js";
import { parseBody } from "./validate.js";

let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

describe("routes", () => {
  it("GET /health returns ok", async () => {
    app = await buildApp({ logger: false });
    const res = await app.inject({ method: "GET", url: "/health" });
    expect(res.statusCode).toBe(200);
    const body = res.json<{ status: string; service: string }>();
    expect(body.status).toBe("ok");
    expect(body.service).toBe("zumi-api");
  });

  it("GET /api/v1 describes the API", async () => {
    app = await buildApp({ logger: false });
    const res = await app.inject({ method: "GET", url: "/api/v1" });
    expect(res.statusCode).toBe(200);
    expect(res.json<{ name: string }>().name).toBe("ZUMI API");
  });

  it("unknown routes return the JSON 404", async () => {
    app = await buildApp({ logger: false });
    const res = await app.inject({ method: "GET", url: "/nope" });
    expect(res.statusCode).toBe(404);
    expect(res.json<{ error: string }>().error).toBe("NOT_FOUND");
  });
});

describe("security behaviour", () => {
  it("sets helmet headers", async () => {
    app = await buildApp({ logger: false });
    const res = await app.inject({ method: "GET", url: "/health" });
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
  });

  it("rate limits repeated requests", async () => {
    app = await buildApp({ logger: false, rateLimitMax: 2 });
    const codes: number[] = [];
    for (let i = 0; i < 3; i++) {
      codes.push((await app.inject({ method: "GET", url: "/health" })).statusCode);
    }
    expect(codes).toEqual([200, 200, 429]);
  });

  it("does not allow cross-origin requests by default", async () => {
    app = await buildApp({ logger: false });
    const res = await app.inject({ method: "GET", url: "/health", headers: { origin: "https://evil.example" } });
    expect(res.headers["access-control-allow-origin"]).toBeUndefined();
  });

  it("allows only the configured origin", async () => {
    app = await buildApp({ logger: false, corsOrigin: "http://localhost:3000" });
    const ok = await app.inject({ method: "GET", url: "/health", headers: { origin: "http://localhost:3000" } });
    const bad = await app.inject({ method: "GET", url: "/health", headers: { origin: "https://evil.example" } });
    expect(ok.headers["access-control-allow-origin"]).toBe("http://localhost:3000");
    expect(bad.headers["access-control-allow-origin"]).toBeUndefined();
  });
});

describe("body validation", () => {
  it("maps validation failures to HTTP 400 and accepts valid bodies", async () => {
    app = await buildApp({ logger: false });
    // Test-only route: the API has no body-accepting product routes yet.
    app.post("/__test/post", async (req) => parseBody(CreatePostSchema, req.body));

    const bad = await app.inject({ method: "POST", url: "/__test/post", payload: { text: "", visibility: "private" } });
    expect(bad.statusCode).toBe(400);
    expect(bad.json<{ error: string }>().error).toBe("VALIDATION_ERROR");

    const good = await app.inject({ method: "POST", url: "/__test/post", payload: { text: "hi", visibility: "private" } });
    expect(good.statusCode).toBe(200);
  });
});

describe("parseCorsOrigins", () => {
  it("returns [] for empty input", () => expect(parseCorsOrigins(undefined)).toEqual([]));
  it("trims entries", () => {
    expect(parseCorsOrigins(" http://a.test , https://b.test ")).toEqual(["http://a.test", "https://b.test"]);
  });
  it("rejects wildcard", () => expect(() => parseCorsOrigins("*")).toThrow());
  it("rejects trailing slash, paths and bad schemes", () => {
    expect(() => parseCorsOrigins("http://a.test/")).toThrow();
    expect(() => parseCorsOrigins("http://a.test/x")).toThrow();
    expect(() => parseCorsOrigins("ftp://a.test")).toThrow();
    expect(() => parseCorsOrigins("not a url")).toThrow();
  });
});
