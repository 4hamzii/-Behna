import { PrismaClient } from "@prisma/client";
import { buildApp } from "./app.js";
import { createPrismaStore } from "./auth/prismaStore.js";
import { consoleMailer, resendMailer } from "./auth/mailer.js";

const port = Number(process.env.API_PORT ?? 4000);
const isProd = process.env.NODE_ENV === "production";

async function main(): Promise<void> {
  const secret = process.env.AUTH_SECRET ?? "";
  const resendKey = process.env.RESEND_API_KEY;
  if (isProd && !resendKey) throw new Error("RESEND_API_KEY is required in production (no console mailer).");

  const store = createPrismaStore(new PrismaClient());
  const app = await buildApp({
    corsOrigin: process.env.CORS_ORIGIN,
    trustProxy: process.env.TRUST_PROXY,
    auth: {
      store,
      mailer: resendKey ? resendMailer(resendKey, process.env.MAIL_FROM ?? "ZUMI <no-reply@example.com>") : consoleMailer,
      secret,
      secureCookie: isProd
    }
  });
  // Hourly housekeeping. unref() so it never keeps the process alive on shutdown.
  setInterval(() => { store.purgeExpired(new Date()).catch((e) => app.log.error(e)); }, 60 * 60 * 1000).unref();
  try {
    await app.listen({ port, host: "0.0.0.0" });
  } catch (error) {
    app.log.error(error);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
