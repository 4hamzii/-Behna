import Fastify, { type FastifyError, type FastifyInstance } from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import cookie from "@fastify/cookie";
import { registerAuthRoutes } from "./auth/routes.js";
import type { AuthStore, Mailer } from "./auth/store.js";
import { parseCorsOrigins, parseTrustProxy } from "./config.js";
import { ValidationError } from "./validate.js";

export interface BuildAppOptions {
  /** Raw CORS_ORIGIN value. */
  corsOrigin?: string | undefined;
  logger?: boolean;
  rateLimitMax?: number;
  rateLimitWindow?: string;
  /** Enables the /api/v1/auth routes. Omit to run without a database. */
  auth?: { store: AuthStore; mailer: Mailer; secret: string; secureCookie: boolean };
  /** Raw TRUST_PROXY value: comma-separated IPs/CIDRs of your reverse proxy (empty = trust none). */
  trustProxy?: string | undefined;
}

export async function buildApp(options: BuildAppOptions = {}): Promise<FastifyInstance> {
  const app = Fastify({
    logger:
      (options.logger ?? true)
        ? {
            redact: {
              paths: ["req.headers.authorization", "req.headers.cookie", 'res.headers["set-cookie"]'],
              censor: "[REDACTED]"
            }
          }
        : false,
    bodyLimit: 1_048_576,
    trustProxy: parseTrustProxy(options.trustProxy)
  });

  const origins = parseCorsOrigins(options.corsOrigin);

  await app.register(helmet);
  await app.register(cors, { origin: origins.length > 0 ? origins : false, credentials: true });
  await app.register(cookie);
  await app.register(rateLimit, {
    max: options.rateLimitMax ?? 100,
    timeWindow: options.rateLimitWindow ?? "1 minute"
  });

  app.get("/health", async () => ({
    status: "ok",
    service: "zumi-api",
    timestamp: new Date().toISOString()
  }));

  app.get("/api/v1", async () => ({
    name: "ZUMI API",
    version: "0.3.1",
    status: "development-foundation",
    note: "Product endpoints are added module by module."
  }));

  if (options.auth) {
    if (options.auth.secret.length < 32 || options.auth.secret.startsWith("REPLACE")) {
      throw new Error("AUTH_SECRET must be a real random value of at least 32 characters (see .env.example).");
    }
    registerAuthRoutes(app, { ...options.auth, allowedOrigins: origins });
  }

  app.setNotFoundHandler(async (_request, reply) => {
    return reply.code(404).send({ error: "NOT_FOUND", message: "Route not found" });
  });

  app.setErrorHandler((error: FastifyError, request, reply) => {
    if (error instanceof ValidationError) {
      return reply.code(400).send({ error: "VALIDATION_ERROR", issues: error.issues });
    }
    const status = error.statusCode ?? 500;
    if (status < 500) {
      return reply.code(status).send({ error: error.code ?? "REQUEST_ERROR", message: error.message });
    }
    request.log.error(error);
    return reply.code(500).send({ error: "INTERNAL_ERROR", message: "Unexpected error" });
  });

  return app;
}
