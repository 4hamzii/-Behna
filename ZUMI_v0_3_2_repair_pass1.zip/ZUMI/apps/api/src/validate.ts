import type { ZodType } from "zod";

export interface ValidationIssue {
  path: string;
  message: string;
}

export class ValidationError extends Error {
  constructor(public readonly issues: ValidationIssue[]) {
    super("Invalid request body");
    this.name = "ValidationError";
  }
}

/** Validate an untrusted request body. Throws ValidationError (mapped to HTTP 400 by the app). */
export function parseBody<T>(schema: ZodType<T>, body: unknown): T {
  const result = schema.safeParse(body);
  if (!result.success) {
    throw new ValidationError(
      result.error.issues.map((i) => ({ path: i.path.join("."), message: i.message }))
    );
  }
  return result.data;
}
