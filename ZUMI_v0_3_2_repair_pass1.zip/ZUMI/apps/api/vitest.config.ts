import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";

// Tests read the shared package straight from source so they do not require a prior build.
export default defineConfig({
  test: { environment: "node" },
  resolve: {
    alias: { "@zumi/shared": fileURLToPath(new URL("../../packages/shared/src/index.ts", import.meta.url)) }
  }
});
