# Architecture decisions

- Website-first launch; native iOS and Android clients are later phases.
- Cross-device synchronization is a core requirement, so server-side persistence is required.
- PostgreSQL is the initial relational database candidate.
- Object storage is required for user media and files; actual provider remains a deployment decision.
- AI integration must be provider-independent.
- Build $0-first where feasible, while recognizing that reliable production hosting, storage, security and operations have ongoing costs.
- No wallet, money transfer, red-packet, mini-program or booking ecosystem in the approved initial scope.
- ZUMI must use original code, visual identity, copy and policy language.

## D-007 (v0.3.1) Password hashing: scrypt now, Argon2id later
Node's built-in scrypt needs no native build, which matters because dependencies could not be installed during development. The stored format names the algorithm, so verification of old hashes can continue while new hashes switch to Argon2id. Revisit when packages can be installed and login latency is benchmarked.

## D-008 (v0.3.1) Modular monolith first
Services are split only when their scaling profile differs (realtime gateway, media pipeline, AI gateway). See ARCHITECTURE_SCALING.md.
