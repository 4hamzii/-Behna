# Status update (2026-11-15 independent audit)
#3 (no migration) is now fixed: baseline migration committed. The database layer HAS now run against real PostgreSQL 16 (via an engine-free Prisma client; native-engine and `prisma migrate deploy` still need a run on your machine). New open items: N-01 pre-registration takeover, N-02 no resend for unverified users, N-03 stale unverified accounts never purged, N-07 unset NODE_ENV fails open, N-08 handle-error mapping unverified on native engine. See docs/audit/AUDIT_2026-11-15_INDEPENDENT.md.

---
# Status update (2026-11-11 verification run)
Resolved: #1 (code now compiled, linted, tested), #2 (lockfile exists), #4 (schema validates), #5 (versions exist; high/critical audit findings cleared), #7 (replaced by `TRUST_PROXY`).
Still open: #3 (no migration yet), CSP `'unsafe-inline'`, and the database layer (`apps/api/src/auth/prismaStore.ts`) has never run against a real PostgreSQL. Items 8-9 below are partly outdated: auth code exists and has a Prisma store.
New: one moderate dev-only advisory (minimatch via typescript-eslint). No browser/screen-reader testing has been done on the web screens.

---
# Known issues (v0.2.0)
1. Nothing in this version has been compiled, linted or tested by the author of this package (no network in the build sandbox). Run the commands in README and trust only your own output.
2. `pnpm-lock.yaml` is missing; the first `pnpm install` creates it. Commit it.
3. No database migration exists yet. Run `pnpm db:migrate --name baseline` once and commit `prisma/migrations`.
4. `prisma/schema.prisma` has not been validated by the Prisma CLI. Run `pnpm db:validate` first and report errors.
5. Next.js `15.5.28` and React `19.2.9` were chosen from third-party security summaries (October 2026); confirm against the official Next.js advisories and `pnpm audit`. If a version does not exist, install the latest patched 15.5.x.
6. CSP uses `'unsafe-inline'` for scripts (see STRIDE.md).
7. `trustProxy` not set (see STRIDE.md).
8. Authentication is implemented in code (v0.3.0) but not run against a database. Authorization for product routes (posts, messages) and all other product endpoints are not built.
9. The API has no database code yet; `@prisma/client` is installed for later use.
10. Web lint is run from the root with a basic TypeScript ruleset; no React/accessibility lint plugins yet.
11. Accessibility is improved but not tested with a screen reader or automated checker.
12. Auth gaps: no MFA/passkeys, no per-device login alerts, no CAPTCHA, no account deletion flow, no disposable-email blocking, scrypt cost (N=32768) not tuned for production, codes are logged to the terminal in development (console mailer).
13. The web screens call the API from the browser; cookies need the web and API on the same site (e.g. app.example.com and api.example.com) in production.
