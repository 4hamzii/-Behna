# Security assessment (self-assessment, v0.3.1)

This is not a penetration test and not independent. Mapping is to OWASP ASVS themes; no ASVS level is claimed.

| Control | State |
|---|---|
| Password storage | scrypt, per-user salt, constant-time compare, NFKC normalisation. Argon2id requested; see F-12 |
| Sessions | 32-byte random opaque token, only SHA-256 hash stored, HttpOnly + SameSite=Lax (+Secure in production), 30-day absolute and 14-day idle expiry, revoke on logout and on password reset |
| One-time codes | CSPRNG 6 digits, HMAC-keyed hash bound to user and purpose, 10-minute expiry, single use, 5 attempts, resend limited |
| Account enumeration | Same response/shape for signup, resend, forgot; same login error; dummy hash for unknown emails; existing owner emailed |
| CSRF | SameSite cookie + Origin check against allowed list on all non-GET requests. Requests with no Origin header are allowed (non-browser clients) |
| Rate limiting | Per route, per IP, in memory (F-07). Not per account |
| Input validation | Zod on every auth body; body size limit 1 MB |
| Headers | Helmet on API; CSP and others on web; CSP still allows inline scripts (F-09) |
| Logging | Authorization/cookie/set-cookie redacted; audit events with no secrets |
| Secrets | `.env` git-ignored; placeholder `AUTH_SECRET` rejected; no secrets in ZIP |
| Dependencies | Not audited (no lockfile, `pnpm audit` not run) |
| MFA / passkeys / WebAuthn | Not built |
| TLS 1.3, key management, backup encryption, DDoS/bot protection | Infrastructure items, none configured. Use a CDN/WAF and managed Postgres with encryption |
| Authorization (RBAC/ABAC) | Only `requireAuth`. Ownership checks must be added with every product route |
| E2E encryption | NOT implemented and must not be advertised |

Highest-risk open items: F-02/F-04 (nothing proven to run), email delivery dependency, no MFA, in-memory rate limits.
