# ZUMI STRIDE threat model (v0.1, DRAFT, desk exercise)

Status: written by the engineering assistant from the planned architecture. NOT reviewed by a security professional. Must be revisited before auth code ships and before launch.

## Data flow (current + planned)
```
Browser/Mobile --HTTPS--> Next.js web --HTTPS--> Fastify API --> PostgreSQL (private)
                                                    |--> Object storage (private, signed URLs) [planned]
                                                    |--> AI provider adapter [planned, keys server-side only]
                                                    |--> Realtime/WebRTC signaling [planned]
```
Trust boundaries: (1) client to API, (2) API to database/storage, (3) API to third-party AI/email providers, (4) admin tooling to API.
Assets: accounts and credentials, session tokens, private messages, private posts/media, emergency and medical info, location, AI memory/documents, audit logs, backups.

## Threats and mitigations
| STRIDE | Threat | Planned mitigation | Status |
|---|---|---|---|
| Spoofing | Credential stuffing, phishing, stolen sessions | Argon2id, passkeys/WebAuthn, MFA, hashed opaque session tokens, device list, login alerts, rate limits | Schema only; rate limit implemented |
| Spoofing | Handle impersonation (Sam/sam) | `handleLower` unique column | Schema only |
| Tampering | SQL injection, mass assignment, IDOR/BOLA | Prisma parameterized queries, Zod body validation, object-level authorization on every route | Validation helper implemented; authz not yet |
| Tampering | Malicious uploads | Type/size checks, scanStatus gate, private storage, no direct execution | Schema only |
| Repudiation | User or admin denies an action | AuditEvent table, no secrets in metadata, restricted access | Schema only |
| Info disclosure | Private content becoming public | Default PRIVATE visibility, visibility enforcement in one service layer, authorization tests | Defaults in schema; enforcement not yet |
| Info disclosure | Secrets in logs | Pino redaction for Authorization/Cookie/Set-Cookie; never log tokens | Implemented (not independently verified) |
| Info disclosure | Cross-user AI memory/document leakage, prompt injection | Per-user scoping, retrieved text treated as untrusted, least-privilege tools, user approval | Not started |
| Info disclosure | Location/medical data sent without consent | Permission-first flows, explicit user action | Not started |
| Denial of service | Request floods, large bodies | Rate limit (100/min per IP default), 1 MiB body limit, later WAF/CDN | Partially implemented |
| Elevation of privilege | Admin tool abuse, role escalation | RBAC, least privilege, audit, separate admin surface | Not started |
| Elevation of privilege | Next.js/React framework vulnerabilities | Pin patched versions, `pnpm audit` in CI, regular updates | Pinned; unverified until installed |

## Known gaps
- `trustProxy` is not configured, so behind a proxy/CDN all users could share one rate-limit bucket. Configure before deployment.
- CSP currently needs `'unsafe-inline'` scripts (Next.js inline scripts). Move to nonces.
- No authentication exists. No data route should be added before auth plus authorization tests.
- Child safety, age assurance and E2EE are separate assessments and are not covered here.
