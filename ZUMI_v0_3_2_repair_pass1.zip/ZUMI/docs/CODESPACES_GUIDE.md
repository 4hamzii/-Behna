# Run ZUMI from an iPhone (GitHub Codespaces, free tier)
You do not need a computer. Use Safari.

1. Create a free account at github.com. Tap Sign up.
2. Create a new PRIVATE repository named `zumi` (tap + then New repository, choose Private).
3. Upload the unzipped project: on iPhone, open the Files app, tap the ZIP to unzip it, then in the GitHub repo tap Add file, Upload files, and choose the files. (Uploading many files from a phone is slow; if it is too hard, ask for help getting the code onto GitHub.)
4. In the repo tap Code, then Codespaces, then Create codespace on main. A coding screen opens in Safari. Free usage is limited each month; stop the codespace when done.
5. In the Terminal at the bottom, type these one at a time and press Return:
   ```
   corepack enable
   pnpm install
   cp .env.example .env
   pnpm db:up
   pnpm db:generate
   pnpm db:validate
   pnpm typecheck
   pnpm lint
   pnpm test
   ```
6. Copy ALL the red/green output into your chat with the assistant. Do not guess; the output tells us what is broken.
7. When those pass, run `pnpm db:migrate --name baseline` then `pnpm dev`. Open the Ports tab to open the web page (port 3000) and the API (port 4000, add /health).
8. Never paste real passwords or keys into chat. The `.env` file is not committed.
