# Architecture and scaling plan

IMPORTANT: 1 billion accounts and 50 million daily users are PLANNING TARGETS, not capabilities. Every figure below is an assumption-based estimate for planning. None has been measured. Capacity is only real once load-tested on real infrastructure.

## Planning assumptions (replace with measured data)
- Peak concurrent users = 5-10% of daily active users (so 50M DAU is roughly 2.5-5M peak concurrent).
- A connected user generates about 1 API request per 10 seconds, plus one realtime connection while the app is open.
- Login (scrypt) costs roughly 50-100 ms CPU each. Most users stay logged in for 30 days, so logins are a small share of traffic but arrive in bursts.
- Read:write ratio about 10:1 for feeds, 1:1 for messaging.

## Milestones
| # | Stage | Peak requests/s (estimate) | Simplest architecture that should fit | Main risk |
|---|---|---|---|---|
| 1 | Development, initial launch | < 10 | 1 web + 1 API container, 1 managed Postgres, Cloudflare in front | Unverified code |
| 2 | 1,000 concurrent | ~100 | Same, 2 API instances behind a load balancer, Redis for rate limits and sessions cache | In-memory rate limits (F-07) |
| 3 | 10,000 | ~1,000 | + read replica, object storage + CDN for media, background worker + queue for email/media | Slow queries without indexes |
| 4 | 50,000 | ~5,000 | + separate WebSocket gateway service, connection pooling (PgBouncer), cache hot reads | Connection counts, fan-out |
| 5 | 100,000 | ~10,000 | Autoscaled API group, partitioned message tables (by time or conversation), dedicated search service | Hot rows, large groups |
| 6 | 1 million | ~100,000 | Multi-AZ everywhere, sharded messaging store, regional CDN, separate AI gateway with budgets | Cost, operational load |
| 7 | 5 million | ~500,000 | Multi-region active/passive, per-region caches, event streaming (Kafka-class) for fan-out | Data residency, failover |
| 8 | 10 million | ~1,000,000 | Multi-region active/active for reads, sharded primary stores, custom realtime layer | Consistency, hot partitions |
| 9 | 50M daily users | as above, sustained | All of the above plus capacity reservation and a dedicated SRE function | People and cost |
| 10 | 1B accounts | storage-dominated | Cold-storage tiers, account sharding, compliance by region | Storage cost, legal |

Rule: move to the next row only when a load test at the current row shows the limit and a cheaper fix is not enough. Microservices are introduced only for pieces with a different scaling profile: realtime gateway, media pipeline, AI gateway. Everything else stays a modular monolith.

## Order-of-magnitude cost (UNVERIFIED planning ranges, USD per month, not quotes)
Rows 1-2: tens to low hundreds. Row 3: hundreds to low thousands. Rows 4-5: low to mid tens of thousands. Row 6: mid hundreds of thousands. Rows 7-9: millions, dominated by egress/CDN, storage and AI inference. Get real quotes from the chosen provider and re-run the numbers with measured per-request costs before committing money.

## Failure modes to design for
Database failover (replica promotion, lag), cache stampede after restart, queue backlog, WebSocket reconnect storms after a gateway restart, email provider outage (codes not delivered), clock skew (token expiry), single-region outage, abusive signups.

## Data protection and recovery targets (proposed)
Daily encrypted backups, point-in-time recovery enabled, restore tested monthly. Proposed targets: RPO 15 minutes, RTO 1 hour at row 4+. Not met today (no backups exist).
