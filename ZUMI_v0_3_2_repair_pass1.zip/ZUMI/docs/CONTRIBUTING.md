# Contribution rules

- Use small, reviewable pull requests.
- Add tests for new business rules and authorization behavior.
- Never commit `.env`, API keys, private keys, user data or production dumps.
- Document schema migrations and rollback considerations.
- Update `TRACEABILITY.md` honestly; distinguish scaffolded from implemented.
- Do not copy another product's proprietary source, branding, policy text or UI.
