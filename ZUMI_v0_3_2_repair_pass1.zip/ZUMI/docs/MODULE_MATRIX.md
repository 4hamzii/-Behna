# Module completion matrix (v0.3.1)

A level is only marked when evidence exists. "No" means not achieved. Level 3 means tests actually passed; Level 4 needs security, performance, operational and legal review.

| # | Module | L1 Source | L2 Functionality | L3 Tested | L4 Production |
|---:|---|---|---|---|---|
| 1 | Account and identity | Partial: signup, verify, login, logout, reset, sessions, screens | Partial: no MFA/passkeys, deletion, CAPTCHA | Partial: 39 automated tests pass (incl. full auth flow on an in-memory store) and the flow was exercised over live HTTP. NOT yet run against a real PostgreSQL | No |
| 2 | Personal profiles | Schema + signup creates profile row only | No | No | No |
| 3 | Social networking | No | No | No | No |
| 4 | Messaging and files | Schema only (and security headers for 23) | No | No | No |
| 5 | Calls and live | No | No | No | No |
| 6 | Communities/channels | Schema only (and security headers for 23) | No | No | No |
| 7 | Zumi Capture | No | No | No | No |
| 8 | Zumi Studio | No | No | No | No |
| 9 | Moments/Stories/Memories | No | No | No | No |
| 10 | Gallery/storage | Schema only (and security headers for 23) | No | No | No |
| 11 | Zumi AI | No | No | No | No |
| 12 | Workspace | No | No | No | No |
| 13 | Zumi Drive | No | No | No | No |
| 14 | Private Notebook | No | No | No | No |
| 15 | Emergency Centre | No | No | No | No |
| 16 | Play/Gaming | No | No | No | No |
| 17 | Entertainment | No | No | No | No |
| 18 | Education | No | No | No | No |
| 19 | Location/Travel | No | No | No | No |
| 20 | Organization/Reminders | No | No | No | No |
| 21 | Search/Discovery | No | No | No | No |
| 22 | Personalization/UI | Minimal CSS shell | No | No | No |
| 23 | Privacy/Security | Schema only (and security headers for 23) | No | No | No |
| 24 | Child Safety/Moderation | No | No | No | No |
| 25 | Accessibility | No | No | No | No |
| 26 | International | No | No | No | No |
| 27 | Admin/Developer | No | No | No | No |
| 28 | Advanced/Future | No | No | No | No |
