# Legal and trust readiness

Starting jurisdiction requested for legal planning: Pakistan. ZUMI also has a global ambition, so legal obligations must be assessed separately for each launch country, platform, age group, and business model. Obtain qualified legal advice; this checklist is not legal advice and does not establish compliance.

Track at least:
- Privacy Policy and Terms of Service/User Agreement.
- Refund/cancellation policy if paid features are introduced.
- Cookie/tracking notice and consent controls where applicable.
- Community Guidelines and Acceptable Use Policy.
- Child safety, age assurance, reporting and moderation processes.
- Copyright/IP complaint and counter-notice process.
- Data export, correction, retention and deletion workflows.
- Law-enforcement request handling and transparency process.
- Accessibility statement and accessibility testing.
- App-store and payment-provider terms before mobile/payment launch.
- Data-processing agreements, vendor register and cross-border transfer review.
- Marketing consent, unsubscribe and notification preferences.

Policies must match actual product behavior. Do not publish generic promises that engineering has not implemented.
