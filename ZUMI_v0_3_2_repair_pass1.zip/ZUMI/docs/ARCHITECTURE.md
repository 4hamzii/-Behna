# Architecture

## Initial shape

```text
Browser
  |
  v
Next.js web app (apps/web)
  |
  v
Fastify API (apps/api)
  |---- PostgreSQL (Prisma schema)
  |---- Object storage (planned adapter)
  |---- AI provider gateway (planned adapter)
  |---- Realtime gateway (planned)
```

The shared package contains validation contracts so web and API can agree on data shapes. Keep business logic in service modules, not in UI components or route handlers.

## Design rules

1. API is the authority for identity, authorization and persisted data.
2. Never trust client-supplied user IDs or visibility checks.
3. Keep media bytes in private object storage; keep metadata and ownership in PostgreSQL.
4. Add explicit authorization tests for every resource.
5. Treat AI providers as replaceable adapters; do not couple core product data to one vendor.
6. Use migrations for every schema change.
7. Build mobile clients against the same versioned API later.
