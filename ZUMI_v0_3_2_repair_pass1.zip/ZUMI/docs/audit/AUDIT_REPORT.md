# ZUMI audit report (v0.3.0 baseline -> v0.3.1)

Method: static reading of every source file, plus the checks listed in the Verification column. This is a SELF-audit by the author of the code; it is not independent. Severity: Critical / High / Medium / Low / Info. Status: Fixed (code changed, verification stated) / Open.

| ID | Sev | Location | Finding and impact | Correction | Verification | Status |
|---|---|---|---|---|---|---|
| F-01 | High | `apps/api/src/auth/routes.ts` `requireAuth` | Declared `Promise<void>` but returned a reply object; likely fails strict typecheck, blocking the build | Return type `Promise<FastifyReply \| void>` (also in the Fastify type augmentation) | Needs `pnpm typecheck` with Fastify installed. Not yet run | Fixed, unverified |
| F-02 | High | repo root | No `pnpm-lock.yaml`; CI uses `--frozen-lockfile` so CI cannot pass; builds not reproducible | Cannot be fixed offline | Run `pnpm install` once, commit the lockfile | **Open** |
| F-03 | High | `prisma/schema.prisma` | Never validated or migrated; auth depends on it | Added `PASSWORD_RESET` purpose and `attempts` column | Needs `pnpm db:validate`, then `pnpm db:migrate --name baseline` | **Open** |
| F-04 | High | whole repo | Auth flow, Prisma store and web screens never executed together | Tests written (`routes.test.ts`, 6 scenarios) | Needs `pnpm test` | **Open** |
| F-05 | Medium | `routes.ts` signup | Existing-email path skipped the email send, so response time could reveal that an account exists | Existing owner now gets a "someone tried to sign up" email (same work, plus a useful warning). Test asserts the notice has no code | Unit test (not yet run); timing needs measurement in staging | Fixed, unverified |
| F-06 | Medium | `routes.ts`, `prismaStore.ts` | Sessions never expired from inactivity; dead sessions, old codes and audit rows grew without limit | 14-day idle timeout, activity recorded hourly, hourly purge job (sessions dead 7+ days, codes 1+ day, audit 180+ days) | Not yet run. Needs a Prisma integration test | Fixed, unverified |
| F-07 | Medium | `app.ts` rate limiting | Counters live in each server's memory; with 2+ servers a client gets N times the limit | Documented. Needs a shared Redis store | Load test across 2 instances | **Open** |
| F-08 | Medium | auth | No MFA/passkeys, no CAPTCHA/bot protection, no breached-password check (only a tiny deny-list), no account deletion/export | Not built | Per-feature tests when built | **Open** |
| F-09 | Medium | `securityHeaders.ts` | CSP allows `'unsafe-inline'` scripts | Needs nonce-based CSP for the chosen host | Header test + browser check | **Open** |
| F-10 | Low | `apps/web/app/forgot/page.tsx` | Two `<main>` elements, duplicate id `main`, two `<h1>` on one page (accessibility) | `AuthForm` has an `embedded` mode (`section` + `h2`); page supplies the single `<main>` | Read in source; needs axe/browser check | Fixed, unverified |
| F-11 | Low | `AuthForm.tsx` | `URLSearchParams.size` may be missing in older browsers | Replaced with `carry.length > 0` | Source | Fixed |
| F-12 | Low | `crypto.ts` | Uses scrypt (N=32768), not Argon2id requested in the master prompt | Kept: Node built-in, no native dependency. Argon2id migration path = store format already carries the algorithm name | Benchmark login latency on the real host; swap if required | Open (decision recorded in DECISIONS.md) |
| F-13 | Low | `validate.ts` | Uses a constructor parameter property; fine for `tsc`, but not runnable by Node's type-stripping | None needed | n/a | Info |
| F-14 | Info | `docker-compose.yml`, `.env.example` | Local-only defaults; `AUTH_SECRET` placeholder is now rejected at startup | n/a | Start API with the placeholder and confirm refusal | Fixed in v0.3.0 |
| F-15 | Info | docs | Earlier README claimed "all fixes done"; now every status says NOT RUN | n/a | Read | Fixed |

Not assessed at all: authorization on product routes (none exist), real-time messaging, media upload, AI, load behaviour, race conditions beyond the single-code-use flow, memory leaks, deployment.
