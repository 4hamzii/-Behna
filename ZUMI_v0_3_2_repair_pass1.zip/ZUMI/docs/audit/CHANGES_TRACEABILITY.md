# Change traceability: v0.3.0 -> v0.3.1

| Change | Files | Finding |
|---|---|---|
| `requireAuth` return type; idle-timeout and activity touch | `apps/api/src/auth/routes.ts` | F-01, F-06 |
| `touchSession`, `purgeExpired` in the store contract and Prisma store | `auth/store.ts`, `auth/prismaStore.ts` | F-06 |
| Hourly purge scheduled | `apps/api/src/server.ts` | F-06 |
| Existing-email notice email | `auth/routes.ts`, `auth/routes.test.ts` | F-05 |
| In-memory test store updated | `auth/routes.test.ts` | F-05, F-06 |
| `embedded` form mode, single `<main>` on forgot page | `apps/web/components/AuthForm.tsx`, `apps/web/app/forgot/page.tsx` | F-10 |
| `.size` removal | `AuthForm.tsx` | F-11 |
| Version 0.3.1, docs | package.json files, `app.ts`, docs | n/a |

Recoverable original: the uploaded `ZUMI_v0_3_0_merged_auth.zip`.
