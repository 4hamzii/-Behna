# Verification log (raw results of what was actually executed)

Environment: offline sandbox, Node 22.23.4, TypeScript 6.0.3 and zod 3.25.76 from a local tool folder. No Fastify, Prisma, Next, React runtime or vitest available. No pnpm.

| Check | Result |
|---|---|
| Password/code helpers run with Node (8 assertions: hash/verify, salts differ, malformed hash, weak passwords, 6-digit codes, unique tokens, user-bound code hash) | 8/8 passed |
| Shared Zod schemas run with real zod (6 assertions) | 6/6 passed |
| `tsc --strict` on `packages/shared` | Clean (only missing `vitest` types for the test file) |
| `tsc --strict` on `auth/crypto.ts`, `auth/store.ts`, `auth/mailer.ts`, `config.ts` | Clean, no errors |
| `tsc` on `apps/web` | Only environment errors (React/Node type packages not resolvable here). Not meaningful |
| API routes, Prisma store, server, web screens, CI sequence | **NOT RUN** |

Anything not in the "passed" or "clean" rows has not been verified.
