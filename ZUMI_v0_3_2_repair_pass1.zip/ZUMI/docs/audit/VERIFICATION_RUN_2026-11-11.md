# Verification run — 2026-11-11
Environment: Node 22.23, pnpm 9.15.0, Linux sandbox. The sandbox could NOT download Prisma engine binaries (binaries.prisma.sh blocked) and had no PostgreSQL. Original ZIP untouched (sha256 5ac33088...2d5).

| Check | Result |
|---|---|
| `pnpm install` | Failed at first (`@fastify/helmet@^12.1.0` does not exist). Fixed; passes; lockfile created |
| `prisma validate` | Failed first (76 errors, single-line enums). Fixed; "schema is valid" |
| `prisma generate` | Types generated (with placeholder engine path). Real engine not downloaded here |
| `pnpm typecheck` | Failed first (numeric `trustProxy`; zod 4 type). Fixed; passes in all 3 packages |
| `pnpm lint` | Passes (exit 0) |
| `pnpm test` | 39/39 pass (web 3, shared 9, api 27) |
| `pnpm build` | Passes (7 web routes, API compiled) |
| `pnpm audit --audit-level=high` | Was 4 high + 2 critical; now 0 (1 moderate dev-only) |
| Live HTTP run (compiled API with in-memory store + `next start`) | All web pages 200 (404 for unknown), security headers present, CORS preflight OK, foreign Origin -> 403, validation 400 with issue list, signup 202, login before verify 403, wrong code 400, verify 200, login 200 + HttpOnly cookie, /me 200 then 401 after logout, duplicate signup looks identical to success, reset 200, old password 401, new password 200 |

NOT verified: real PostgreSQL (`prismaStore.ts`), baseline migration, browser rendering/clicking, screen readers, performance, penetration testing, email delivery via Resend. Level 3 (Tested and Verified) is therefore only partly reached for Account and identity.
