# Original project inventory (Phase 1 and 2)

Baseline: `ZUMI_v0_3_0_merged_auth.zip` (byte-identical to the build delivered earlier; sha256 prefix af9c3f45390ccfc0). A recoverable copy of this baseline is kept outside the working tree as `ORIGINAL_v0_3_0` (the user's uploaded ZIP is the master copy).

| Area | Path | Contents |
|---|---|---|
| Root | `package.json`, `pnpm-workspace.yaml`, `tsconfig.base.json`, `eslint.config.mjs`, `vitest.config.ts`, `docker-compose.yml`, `.env.example`, `.gitignore`, `LICENSE`, `README.md` | pnpm monorepo, Node >= 22, pnpm 9.15.0 |
| API | `apps/api/src` | Fastify 5 app builder, config (CORS parsing), validation helper, server entry, **auth module** (`auth/crypto.ts`, `store.ts`, `prismaStore.ts`, `mailer.ts`, `routes.ts`) |
| Web | `apps/web` | Next.js 15 shell, security headers, screens: `/`, `/signup`, `/verify`, `/login`, `/forgot`, `/account`, shared `AuthForm` |
| Shared | `packages/shared/src` | Zod schemas (posts, profile, auth), BigInt helper |
| Database | `prisma/schema.prisma` | 24 models. No migrations |
| CI | `.github/workflows/ci.yml` | install, generate, validate, typecheck, lint, test, build, audit |
| Docs | `docs/` | architecture, security baseline, STRIDE, legal readiness, traceability, known issues |

Dependencies (declared, none installed, no lockfile): fastify, @fastify/cors, @fastify/helmet, @fastify/rate-limit, @fastify/cookie, zod, @prisma/client, next, react, react-dom, vitest, eslint, typescript, tsx.

Not present: lockfile, migrations, node_modules, any product feature beyond authentication, Redis/queue/object-storage code, WebSocket/real-time code, AI code.
