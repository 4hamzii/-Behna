# Independent audit and first repair pass — ZUMI v0.3.1 -> v0.3.2 (working branch `repair/phase1-audit`)

Baseline: `3.zip`, sha256 `af1ad354699a889e88229f39094a627bac21d41028ae9ac86738bc6ed2c02677`. Untouched copy kept read-only; first git commit of the working copy is that baseline.

## Test environment (and its limits — read this)
- Node 22.23, pnpm 9.15.0, **PostgreSQL 16.15 (real, installed locally)**. Same major version as `docker-compose.yml`.
- The sandbox **cannot download Prisma's native engine** (`binaries.prisma.sh` blocked). So:
  - `prisma generate --no-engine` was used for types, and `prisma validate` was run with placeholder engine paths.
  - Database behaviour was tested with a scratch harness *outside the repo* that runs the repo's own `app.ts` / `auth/*.ts` **byte-for-byte (checked with `cmp`)** against real PostgreSQL through Prisma's engine-free client + `@prisma/adapter-pg`.
  - What that cannot prove: the project's configured native Prisma engine, `prisma migrate dev/deploy` itself, and the exact shape of Prisma error objects on the native engine.
- No browser, Docker or screen reader was available: **UI behaviour in a real browser is untested**.

## Results of the project's own checks (fresh clone, `--frozen-lockfile`)
| Check | Result |
|---|---|
| `pnpm install --frozen-lockfile` | Pass |
| `prisma validate` | Pass |
| `pnpm typecheck` / `pnpm build` | **Fail on a fresh clone until Prisma types are generated** (3 errors in `prismaStore.ts`); pass once `prisma generate` has run (see N-10) |
| `pnpm lint` | Pass |
| `pnpm test` (before changes) | 39/39 pass (web 3, shared 9, API 27) — but all API tests use an in-memory store |
| `pnpm audit --audit-level=high` | 0 high; 1 moderate (dev-only: minimatch via typescript-eslint) |
| Web production build, `next start` | `/ /signup /login /verify /forgot /account` = 200, unknown path = 404; CSP and 5 other security headers present |
| Baseline DDL from `schema.prisma` applied to real PostgreSQL 16 | Pass: 22 tables, 59 indexes, 29 foreign keys |

## Live-database results (real PostgreSQL), before any change
Pass: signup -> verify -> login -> /me -> logout; correct rows in User/Profile/PrivacySettings/Credential; privacy defaults private; scrypt hash stored, no plaintext; duplicate email indistinguishable from success; 5 simultaneous identical signups = 1 account, no errors; password reset revokes all sessions and the old password; idle-session rejection; purge of dead sessions; login rate limit (429 after 10); 1 MB body limit (413); foreign Origin (403); unknown-email vs wrong-password responses identical; cookie is HttpOnly + SameSite=Lax.

## Findings
| ID | Sev | Finding | Evidence | Status |
|---|---|---|---|---|
| N-01 | High | **Pre-registration takeover.** Someone can sign up with another person's email and their own password. The account stays unverified, but the password survives: when the real owner later verifies the email, the first person can log in. | Live test: attacker login after victim verified -> HTTP 200 | **Open — needs owner decision** |
| N-02 | High (usability) | **Unverified users get stuck.** Re-signing up with an unverified email sends no code; the web UI never calls `/auth/resend`; codes last 10 minutes; the /verify page says "start again", which does not help. | Live test: re-signup mail has no code; no `resend` in `apps/web` | **Open — same decision as N-01** |
| N-03 | Medium | Never-verified accounts are never deleted, so they hold a handle and email forever. | Live test: 90-day-old PENDING account survives `purgeExpired` | **Open — same decision as N-01** |
| N-04 | Medium | `scryptSync` blocked the whole server (~75-90 ms per login/signup). | 12 parallel logins froze the server for **523 ms** | **Fixed**, now **21 ms** (live) |
| N-05 | Medium | The "5 guesses per code" limit was check-then-increment, so parallel requests all got free guesses; a code could also be used twice at once. | 30 parallel wrong guesses recorded **25** attempts (limit 5) | **Fixed**, now **5** (live) + 2 regression tests |
| N-06 | High (deploy) | No `prisma/migrations`, so the database cannot be created reproducibly. | `ls prisma` showed only `schema.prisma` | **Fixed** (baseline migration) — see caveat below |
| N-07 | Medium | If `NODE_ENV` is not set, the API treats itself as development: verification codes are printed to the log and the cookie is not `Secure`. | Read from `server.ts`; not run | Open |
| N-08 | Low | The API turns a duplicate-handle database error into "handle taken" only if the error carries `meta.target`; any other shape is silently treated as "email taken" and the user is told to check their email for an account that was not created. The database itself rejects `Meta` vs `META` correctly (`Profile_handleLower_key`). | Engine-free driver reports a different error shape, so native-engine behaviour is **unverified** | Open — verify on native engine |
| N-09 | Low | `Device` table is never written; `Session.deviceId` is always null; there is no device/session management (Category 1 gap). | grep | Open (feature work) |
| N-10 | Low | `pnpm typecheck` / `pnpm build` fail on a fresh clone until `pnpm db:generate` is run. | See table above | Open |
| N-11 | Info | No graceful shutdown (`$disconnect`) in `server.ts`; `/health` does not check the database. | Read from code | Open |
| N-12 | Info | CSP still allows `'unsafe-inline'` scripts (known F-09); in-memory rate limiting (F-07); scrypt not Argon2id (F-12). | Existing docs | Open |

## What actually exists vs the 28 categories
10 API routes (8 auth, `/health`, `/api/v1`). 7 of the 22 database tables are used by code (User, Profile, PrivacySettings, Credential, VerificationToken, Session, AuditEvent). **Only Category 1 (Account and identity) is partly built; Categories 2-28 are not started** (matches `docs/MODULE_MATRIX.md`).

## Repairs made in this pass
1. **N-04** `apps/api/src/auth/crypto.ts`, `routes.ts`: password hashing is now asynchronous (same stored hash format; old hashes still verify). Tests: `crypto.test.ts` (+2).
2. **N-05** `store.ts`, `prismaStore.ts`, `routes.ts`: `claimAttempt()` and `consumeVerification()` are single atomic database operations. Tests: `routes.test.ts` (+2: 30 simultaneous guesses allow exactly 5; a reset code submitted twice at once works once).
3. **N-06** `prisma/migrations/20261114000000_baseline/migration.sql` + `migration_lock.toml`, generated by Prisma's own schema engine from `schema.prisma`, applied to a fresh PostgreSQL 16 database, and structurally compared with the tested database (identical apart from `pg_dump`'s random per-run tokens). **Not verified:** running `prisma migrate dev` / `migrate deploy` natively — run it once on your machine or in CI.

## After-change results
- `pnpm typecheck`, `pnpm lint`: pass. `pnpm test`: 43/43 pass (web 3, shared 9, API 31).
- Live PostgreSQL: 8 of 12 audit tests pass. The 4 that still fail are exactly N-01, N-02, N-03 and N-08 (the last is a driver-shape artifact, not a confirmed bug).
- One of my own new tests failed first (20 of 30 requests got HTTP 429). Cause: every test request came from one IP and the per-IP limiter (correctly) blocked them. The test, not the fix, was wrong; it now uses a different IP per request.
