# ZUMI feature traceability and completion register

Status vocabulary:
- **Planned** — approved scope, not implemented.
- **Scaffolded** — structure or placeholder exists.
- **Implemented** — code exists for the described behavior.
- **Tested** — automated/manual evidence recorded.
- **Production Approved** — security, legal, operational and product gates passed.

Completion levels are separate for every module:
1. Source Code Complete
2. Functionality Complete
3. Tested and Verified
4. Production Approved

| # | Category | Initial status | Next engineering milestone |
|---:|---|---|---|
| 1 | Account and identity | Scaffolded | Registration, verification, recovery, passkeys/MFA |
| 2 | Personal profiles | Scaffolded | Profile CRUD, field privacy and validation |
| 3 | Social networking | Planned | Follow/friend graph, blocks and permissions |
| 4 | Messaging and files | Scaffolded | Authorized messaging, uploads, delivery states |
| 5 | Calls and live | Planned | WebRTC/signaling, abuse and quality controls |
| 6 | Communities/channels | Scaffolded | Roles, moderation, membership workflows |
| 7 | Zumi Capture | Planned | Browser/mobile capture workflows |
| 8 | Zumi Studio | Planned | Media editing pipeline |
| 9 | Moments/Stories/Memories | Planned | Expiry, audience and screenshot policy assessment |
| 10 | Gallery/storage | Scaffolded | Private object storage, quotas and export |
| 11 | Zumi AI | Planned | Provider gateway, consent, citations and safety |
| 12 | Workspace | Planned | Document/sheet/slide/PDF modules |
| 13 | Zumi Drive | Planned | File sync, sharing and recovery |
| 14 | Private Notebook | Planned | Private notes and device/session security |
| 15 | Emergency Centre | Planned | SOS flows, consent and regional emergency review |
| 16 | Play/Gaming | Planned | First game: Hide & Seek |
| 17 | Entertainment | Planned | Rights-cleared media and creator tools |
| 18 | Education | Planned | Learning modules, quizzes and progress |
| 19 | Location/Travel | Planned | Permission-first location and travel tools |
| 20 | Organization/Reminders | Planned | Tasks, reminders and calendar integration |
| 21 | Search/Discovery | Planned | Search indexing, privacy filtering and ranking |
| 22 | Personalization/UI | Scaffolded | Themes, accessibility and preferences |
| 23 | Privacy/Security | Scaffolded | Full controls, threat model and independent review |
| 24 | Child Safety/Moderation | Planned | Age-appropriate controls and operational moderation |
| 25 | Accessibility | Planned | WCAG testing and assistive-technology support |
| 26 | International | Planned | Localization, time zones and regional operations |
| 27 | Admin/Developer | Planned | RBAC, audit tools and secure operations |
| 28 | Advanced/Future | Planned | Separate product approval per feature |

This register is intentionally conservative. A database table or placeholder does not mean a user-facing feature is complete.
