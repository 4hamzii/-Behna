# Research and reference register

Honest status: during this work no books, papers, AI-coding products or standards documents were consulted or compared. Nothing was browsed, and no ranking or benchmark is claimed. Decisions in `DECISIONS.md` rest on the author's general engineering knowledge.

Authoritative sources to consult before the next architecture decision (not yet read for this project):
- OWASP ASVS and OWASP Top 10; OWASP Cheat Sheet Series (Password Storage, Session Management, CSRF).
- NIST SP 800-63B (authentication), NIST Cybersecurity Framework.
- W3C WebAuthn Level 2/3 and FIDO2; WCAG 2.2.
- PostgreSQL official documentation (indexing, partitioning, replication, backup).
- Next.js, React, TypeScript, Fastify and Prisma official docs and security advisories.
- Cloud provider well-architected guides for the chosen host.

Rule for future entries: record title, version/date, what was read, and the decision it influenced. No entry without having actually read it.
