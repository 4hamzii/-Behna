# Changelog

## Unreleased — repair pass 1 (2026-11-15)
- Fixed: password hashing no longer freezes the server (async scrypt; stored hash format unchanged). Measured on real PostgreSQL: worst freeze during 12 parallel logins 523 ms -> 21 ms.
- Fixed: verification-code attempt limit and single-use are now atomic database operations (30 parallel guesses recorded 25 attempts before, 5 after). Store interface: `bumpAttempts` replaced by `claimAttempt(id, max)`; `consumeVerification` now returns boolean.
- Added: baseline Prisma migration `20261114000000_baseline` (22 tables) generated from `schema.prisma`; applied to a fresh PostgreSQL 16 and structurally compared with the tested database.
- Added: 4 regression tests (43 total). Added `docs/audit/AUDIT_2026-11-15_INDEPENDENT.md`.
- Not changed: UI/theme, features, dependencies.

## 0.3.1 — verification-run fixes (2026-11-11)
First time the project was actually installed, built and run. Found and fixed:
- `@fastify/helmet@^12.1.0` does not exist on npm (install failed). Now `^12.0.1`. `pnpm-lock.yaml` generated.
- `prisma/schema.prisma` failed validation (76 errors): every `enum` was on one line. Now one value per line. Schema passes `prisma validate`.
- Fastify 5.12 no longer supports numeric `trustProxy` (type error + spoofable). `TRUST_PROXY_HOPS` hop count replaced by `TRUST_PROXY` (IP/CIDR list, `*`/`true` rejected). Tests added.
- Dependency audit: vitest 3→4, zod 3→4 (`validate.ts` type import), overrides for postcss and deepmerge-ts. High/critical findings cleared (1 moderate dev-only remains: minimatch).
- `pnpm dev` now builds `@zumi/shared` first and the API loads the root `.env`.
- Web: validation errors from the API are shown (was a generic message); forgot-password shows a confirmation.
- `.gitignore`: `*.tsbuildinfo`, `next-env.d.ts`. Next.js added `isolatedModules` to `apps/web/tsconfig.json`.
- Evidence: docs/audit/VERIFICATION_RUN_2026-11-11.md.

## 0.3.1
- Fixes from the self-audit (docs/audit/AUDIT_REPORT.md): requireAuth type, session idle timeout and hourly purge, existing-email notice on signup, forgot-page accessibility.
- Added audit, architecture/scaling, security, performance, module matrix and research register documents.
- Verification actually executed is listed in docs/audit/VERIFICATION_LOG.md. Everything else is NOT RUN.

## 0.3.0 (merge of ZUMI_v0_2_0_static_audit.zip + New_1.zip)
- Merged both archives. New_1.zip was an exact subset of the audit ZIP (same 61 files, minus PHASE2_STATIC_AUDIT.md), so nothing conflicted.
- Implemented authentication (closes the P0 "authentication absent" finding in code; NOT yet run against a real database):
  signup, 6-digit email verification, resend, login, logout, forgot/reset password, /auth/me, session cookies (HttpOnly, SameSite=Lax, Secure in production).
- Security controls: scrypt password hashing, hashed session tokens, HMAC-keyed code hashes, 5-attempt code lockout, single-use 10-minute codes, per-route rate limits, uniform error/response shapes (no account enumeration), constant-time login path, Origin check on state-changing requests, all sessions revoked on password reset, audit events.
- Schema: added VerificationPurpose.PASSWORD_RESET and VerificationToken.attempts (still unvalidated by the Prisma CLI).
- API: optional `auth` dependency injection (store + mailer), `trustProxyHops` option, @fastify/cookie.
- Web: /signup, /verify, /login, /forgot (with reset), /account screens.
- Tests added: crypto helpers (executed with Node during packaging: 8/8 passed), auth flow with in-memory store (written, NOT RUN: needs `pnpm install`), shared auth schemas (NOT RUN).

## 0.2.0
- See previous notes: Phase 1 audit fixes (all NOT RUN by the author).
