# ZUMI v0.2.0 — Phase 2 Static Source Audit

**Audit type:** Static inspection of the supplied ZIP archive  
**Audit date:** 2026-11-07  
**Scope:** Repository structure, package scripts, API/web source, Prisma schema, CI workflow, security and readiness documentation.  
**Execution status:** Static inspection only. Dependency installation and runtime checks could not be completed because the environment could not reach the npm registry.

## 1. Executive result

The archive is structurally readable and contains a useful website/API/database foundation. It is not a complete ZUMI product and is not ready for public deployment. The README and traceability register correctly disclose much of this limitation.

No source-code changes are represented as fixes in this audit. Findings below must be addressed and verified in a network-enabled development environment.

## 2. Checks performed

- ZIP archive listing and extraction completed.
- Confirmed 61 archive entries and approximately 59.8 KB of uncompressed file content.
- Inspected root and workspace package manifests, API routes/configuration/validation, web shell/security headers, shared schemas/tests, Prisma schema, CI workflow, Docker Compose, and readiness documentation.
- Confirmed Node.js v22.16.0 is available in the audit environment.
- Confirmed `pnpm` is not installed, no `node_modules` directory is present, and `pnpm-lock.yaml` is absent.
- Attempted to invoke the pinned package manager through Corepack; download failed because `registry.npmjs.org` was unreachable.

## 3. Findings

### P0 — CI installation is blocked by missing lockfile

`.github/workflows/ci.yml` runs `pnpm install --frozen-lockfile`, but the repository does not contain `pnpm-lock.yaml`. A frozen install cannot reliably proceed without the committed lockfile. Generate the lockfile using the declared pnpm version in a network-enabled environment, review it, and commit it. Do not remove frozen-lockfile merely to hide the missing lockfile.

### P0 — Authentication and authorization are absent

The API currently exposes only `/health` and `/api/v1`. There is no implemented registration, login, session lifecycle, account recovery, authorization middleware, or protected product endpoint. Database credential/session models are schema declarations only and do not provide authentication. Do not expose the service to real users or store real user data until these controls are implemented and reviewed.

### P1 — Database schema has not been validated or migrated

There is no `prisma/migrations` directory. The Prisma schema is explicitly marked as a draft and has not been validated by the Prisma CLI. Run `pnpm db:validate`, generate a reviewed baseline migration against a disposable development database, and commit the migration before treating the schema as deployable.

### P1 — Product functionality is mostly planned or scaffolded

The web homepage is a static development-preview page. The API has no user-facing product routes and does not access Prisma. The shared package has a small set of validation contracts. The 28-category traceability table correctly records most product areas as Planned or Scaffolded. This is a foundation, not a functioning social platform.

### P1 — Runtime verification is outstanding

No dependency installation, typecheck, lint, unit tests, build, Prisma generation, or Prisma validation could be run in this environment. The existence of test files is not evidence that tests pass. Run the complete documented CI sequence and retain the raw logs before changing any module status to Tested and Verified.

### P1 — Reverse-proxy trust and rate limiting need deployment-specific configuration

The API does not configure Fastify `trustProxy`. Behind a reverse proxy, client IP handling and rate-limit behavior may not match the intended deployment. Configure only the actual trusted proxy addresses/hops for the chosen host; do not blindly enable trust for all proxies. Verify per-client rate limiting in staging.

### P1 — CSP is not yet strict

`apps/web/lib/securityHeaders.ts` permits `'unsafe-inline'` in `script-src`, and development additionally permits `'unsafe-eval'`. The code comments acknowledge this. Before production, implement and test a nonce/hash-based policy compatible with the chosen Next.js deployment and remove unsafe allowances where feasible.

### P2 — Dependency versions and vulnerability status are unverified

The package manifest pins Next.js and React versions, but the repository has no lockfile and no successful package audit output. Confirm versions against official advisories, generate the lockfile, run `pnpm audit --audit-level=high`, and review transitive dependencies before release.

### P2 — Accessibility is not verified

The web shell includes a skip link, focus styles, responsive layout, and reduced-motion handling. There is no evidence of WCAG conformance, automated accessibility testing, or screen-reader testing. Record results from suitable automated and manual checks.

## 4. Positive observations

- The README clearly says this is a development foundation, not a production-ready product.
- The API separates app construction from server startup and includes health/version routes.
- API tests cover basic routes, CORS behavior, rate limiting, and body validation.
- Shared schemas require an explicit post visibility and reject empty posts.
- The API sets a request body limit and redacts selected authorization/cookie headers from logs.
- CORS configuration rejects wildcard origins and malformed origins.
- Docker Compose binds the local PostgreSQL port to loopback.
- Security, legal, deployment, threat-model, and traceability documents are present and generally avoid claiming completed controls.

## 5. Required next actions, in order

1. Open the project in a network-enabled development environment (GitHub Codespaces is suitable from an iPhone browser).
2. Install the exact declared pnpm version and run `pnpm install`; commit the generated `pnpm-lock.yaml`.
3. Run `pnpm db:validate` and fix every Prisma validation error.
4. Start a disposable local PostgreSQL database, generate a baseline migration, and review it before committing.
5. Run `pnpm typecheck`, `pnpm lint`, `pnpm test`, and `pnpm build`; save complete logs.
6. Fix failures and rerun the full sequence. Do not mark checks passed based on file presence.
7. Implement authentication and authorization before any real-user or public deployment work.
8. Address CSP and trusted-proxy configuration for the actual hosting environment.
9. Continue feature development module by module with separate completion evidence for all four required levels.

## 6. Completion assessment

| Completion level | Assessment |
|---|---|
| Source Code Complete | Only selected foundation components have source code; full product is incomplete. |
| Functionality Complete | Not achieved for the full product. |
| Tested and Verified | Not established; runtime checks were not executed. |
| Production Approved | Not achieved. |

**Final verdict:** The supplied v0.2.0 ZIP is a useful starter foundation, but it has blocking setup/verification work and major product/security implementation still outstanding. This report is a static audit, not a penetration test, legal opinion, or production approval.
