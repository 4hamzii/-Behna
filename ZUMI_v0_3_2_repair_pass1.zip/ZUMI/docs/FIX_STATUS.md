# Fix status against Phase 1 audit
Legend: Done = code written. NOT RUN = never executed by the author (no network). Not done = not completed.

| # | Fix | Status |
|---|---|---|
| 1 | API ESM startup, NodeNext, buildApp()/server split | Done, NOT RUN |
| 2 | Real Fastify inject() tests (/health, /api/v1, 404) | Done, NOT RUN |
| 3 | Tests exist in every package | Done, NOT RUN |
| 4a | @prisma/client dependency | Done, NOT RUN |
| 4b | Baseline migration | Not done (needs Prisma CLI + database) |
| 4c | pnpm-lock.yaml | Not done (needs network install) |
| 5 | @zumi/shared wired to API; Zod body validation helper + 400 mapping | Done, NOT RUN. No product route accepts bodies yet. |
| 6 | README matches real files | Done |
| 7 | ESLint config + CI workflow with audit | Done, NOT RUN |
| 8 | docker-compose.yml (Postgres, loopback only) | Done, NOT RUN |
| 9 | Rate limit, strict CORS parsing, log redaction | Done, NOT RUN |
| 10 | CSP/security headers, skip link, focus styles, 12px min, reduced motion, h1 spacing | Done, NOT RUN |
| 11 | Next.js/React patched versions pinned | Done, unverified against primary advisories |
| DB | Schema revision (auth, social graph, media, cascades, handleLower, sync, receipts, attachments, BigInt helper) | Done, not validated by Prisma |
| Doc | STRIDE threat model | Done (desk exercise, unreviewed) |
| Doc | Changelog | Done |

## v0.3.0 additions (against PHASE2_STATIC_AUDIT.md)
| Audit finding | Status |
|---|---|
| P0 lockfile missing | Not done. Needs network: run `pnpm install` once and commit pnpm-lock.yaml |
| P0 authentication absent | Code written (apps/api/src/auth). NOT RUN. Not reviewed by a security professional |
| P1 schema not validated/migrated | Schema extended. Not done: `pnpm db:validate` and baseline migration |
| P1 runtime verification outstanding | Only crypto helpers were executed (8/8 passed). Everything else NOT RUN |
| P1 trustProxy | Option added (TRUST_PROXY_HOPS). Must be set to match the real host |
| P1 CSP unsafe-inline | Not done |
| P2 dependency audit, accessibility | Not done |
