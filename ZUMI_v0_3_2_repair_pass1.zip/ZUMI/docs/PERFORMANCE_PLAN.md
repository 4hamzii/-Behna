# Performance plan

No performance measurement has been done. Nothing here is a result.

## Proposed SLOs (to be agreed and then measured)
| Indicator | Target |
|---|---|
| API availability (monthly) | 99.9% at launch, higher later. Error budget 43 minutes/month |
| Read API p95 latency | < 300 ms |
| Write API p95 latency | < 500 ms |
| Login p95 latency | < 800 ms (scrypt cost dominates) |
| Message delivery p95 (same region) | < 1 s |
| Email code delivery p95 | < 30 s |

## Test plan
1. Per-route benchmarks with k6 or autocannon against a staging copy with a realistic database size.
2. Load model per milestone using the assumptions in ARCHITECTURE_SCALING.md; ramp, steady, spike.
3. Stress to failure to find the first bottleneck (expected: DB connections, then CPU on password hashing).
4. Failure injection: kill an API instance, kill the DB primary, drop email provider, flood signups.
5. Backup restore drill.
6. Record raw results in `docs/audit/` with date, commit hash and environment. Only then change capacity claims.
