# Deployment outline

1. Create managed PostgreSQL and a private object-storage bucket.
2. Configure secrets in the hosting provider's secret manager.
3. Run Prisma migrations through a controlled release job.
4. Deploy API and web app separately.
5. Configure TLS, DNS, WAF, rate limits, monitoring and alerting.
6. Verify backup restoration and rollback before accepting users.
7. Use staging data that contains no real personal information.
8. Complete legal, privacy, accessibility, security and load-test gates.

Do not deploy publicly until authentication and authorization are implemented and reviewed.
