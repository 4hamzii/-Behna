# Security baseline — implementation required

This document is a checklist, not proof of security.

- [ ] Threat model and data-flow diagrams approved.
- [ ] Password hashing with Argon2id (if passwords are supported).
- [ ] Passkeys/WebAuthn and phishing-resistant MFA.
- [ ] Secure, rotated sessions; CSRF protections where applicable.
- [ ] TLS 1.3 in production; secure headers; restrictive CORS.
- [ ] Authorization checks at every API boundary and object level.
- [ ] Rate limiting, bot controls, abuse detection and account recovery protections.
- [ ] Encryption at rest and managed key lifecycle; HSM/KMS evaluation.
- [ ] Secrets manager; no secrets in source control or logs.
- [ ] Private object storage, signed short-lived URLs, malware scanning.
- [ ] Audit logging with retention and access controls.
- [ ] Dependency scanning, SBOM, signed builds and release provenance.
- [ ] Backup encryption, restore drills, disaster recovery objectives.
- [ ] Independent penetration test and remediation before launch.
- [ ] Incident response, vulnerability disclosure and security contact.
- [ ] Privacy-by-design review and age-appropriate safety controls.

Do not claim end-to-end encryption unless the protocol, key management, multi-device design, backups, and independent review support that claim.
