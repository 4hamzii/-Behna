# ZUMI — Master Project Foundation (v0.3.1)

**Status:** Development foundation / starter repository. This is not a finished, production-ready social platform.

ZUMI is designed as an original, modular, website-first product with later iOS and Android clients. This repository establishes the initial architecture, shared contracts, API skeleton, database model, web shell, security baseline, tests, and delivery documentation.

## What is included

- `apps/web`: Next.js + TypeScript web application shell.
- `apps/api`: Fastify + TypeScript API with health and versioned API routes.
- `packages/shared`: shared Zod schemas and TypeScript contracts.
- `prisma`: PostgreSQL schema for accounts, profiles, posts, conversations, messages, media metadata, notifications, privacy settings, and audit events.
- `docs`: architecture, security, privacy, legal-readiness, deployment, and feature traceability documents.
- Tests live next to code (`*.test.ts`) in each package.
- `docker-compose.yml`: local PostgreSQL (loopback only). `.github/workflows/ci.yml`: CI checks.
- `.env.example`: configuration template; contains no secrets.

## Repair pass 1 (2026-11-15) — read `docs/audit/AUDIT_2026-11-15_INDEPENDENT.md`

An independent audit ran the project against a real PostgreSQL 16. Fixed and verified: the server freezing while passwords are hashed, the 5-guess code limit being bypassable with parallel requests, and the missing database migration (`prisma/migrations/20261114000000_baseline`). Still open and waiting for an owner decision: unverified signups can be hijacked and cannot be resent a code from the web UI (audit N-01/N-02/N-03). Only Category 1 (Account and identity) is partly built; the other 27 categories are not started.

## v0.3.1 status

See `docs/audit/` (inventory, audit report, verification log, final self-audit) and `docs/MODULE_MATRIX.md`.

**Verification run (2026-11-11):** install, schema validation, typecheck, lint, 39 tests and the production build all pass, and the auth flow works over live HTTP — see `docs/audit/VERIFICATION_RUN_2026-11-11.md`. Still open: the baseline migration (`pnpm db:migrate --name baseline`, needs a live database) and a run against real PostgreSQL.
Notes: set `TRUST_PROXY` (IP/CIDR list) when deployed behind a proxy; the web app reads `apps/web/.env.local` (not the root `.env`) if you need to change `NEXT_PUBLIC_API_URL`.

## v0.3.0 status

v0.3.0 merges the two uploaded ZIPs and adds authentication (signup, email code, login, logout, password reset) in `apps/api/src/auth` plus web screens. Only the crypto helpers have been executed; run the full check sequence below and trust only your own output. Posts, messaging, communities, AI and the rest of the 28 categories are NOT built.

## v0.2.0 status

This version fixes issues from the Phase 1 audit, but **it has not been executed by its author** (no network available). See `docs/FIX_STATUS.md` and `docs/KNOWN_ISSUES.md`. Run install, typecheck, lint and test yourself and share the real output.

## Important completion statement

The ZIP does **not** implement all 28 ZUMI categories or all requested features. The current code is a foundation:
- Source Code Complete: only for the small foundation components explicitly implemented here.
- Functionality Complete: not achieved for the full ZUMI product.
- Tested and Verified: only the included automated checks can be considered test candidates; run them in your environment.
- Production Approved: **not achieved**. Security review, legal review, load testing, operational controls, and deployment approval remain outstanding.

Never describe ZUMI as fully built, secure, compliant, or production-ready on the basis of this starter.

## Requirements

- Node.js 22+
- pnpm 9+
- PostgreSQL 16+

## Quick start

```bash
corepack enable
pnpm install
cp .env.example .env
# Edit DATABASE_URL and AUTH_SECRET before running.
docker compose up -d db   # or: pnpm db:up
pnpm db:generate
pnpm db:validate
pnpm db:migrate                  # applies the committed baseline migration in prisma/migrations
pnpm dev
```

Web: http://localhost:3000  
API: http://localhost:4000/health

## Main scripts

```bash
pnpm dev
pnpm build
pnpm lint
pnpm typecheck
pnpm test
pnpm db:generate
pnpm db:migrate
```

## Security warning

Do not deploy with placeholder secrets. Do not store passwords in plaintext. The included account model intentionally does not claim a complete authentication implementation. Before public launch, implement and independently review registration, verification, passkeys/MFA, session management, abuse prevention, encryption/key management, backups, incident response, and privacy workflows.

## Product direction retained

- Website-first launch; mobile apps later.
- Cross-device synchronization is required, so a backend/database/object-storage architecture is necessary.
- User-controlled export, recovery, backup, and deletion are required.
- Original ZUMI branding, code, UI, policies, and content; do not copy proprietary material from other products.
- Build $0-first where practical, then scale deliberately.
- Track each module independently at four levels: Source Code Complete, Functionality Complete, Tested and Verified, Production Approved.

## Try the login flow (after the quick start above)

1. Put a real random value in `AUTH_SECRET` in `.env` (command is in `.env.example`).
2. `pnpm dev`, open http://localhost:3000/signup.
3. Sign up. The 6-digit code is printed in the API terminal (development mailer).
4. Enter it at /verify, then log in at /login. /account shows you are signed in.
5. Run `pnpm typecheck && pnpm lint && pnpm test && pnpm build` and read any failure honestly.
