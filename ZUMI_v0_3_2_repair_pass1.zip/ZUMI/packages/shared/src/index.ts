import { z } from "zod";

export const UserIdSchema = z.string().uuid();
export const VisibilitySchema = z.enum(["private", "friends", "community", "public"]);
export const AccountStatusSchema = z.enum(["pending", "active", "suspended", "deleted"]);

export const PublicProfileSchema = z.object({
  id: UserIdSchema,
  handle: z.string().min(3).max(30),
  displayName: z.string().min(1).max(80),
  bio: z.string().max(500).optional(),
  avatarMediaId: z.string().uuid().nullable().optional()
});

export const CreatePostSchema = z.object({
  text: z.string().max(10_000).default(""),
  visibility: VisibilitySchema,
  mediaIds: z.array(z.string().uuid()).max(10).default([])
}).refine((v) => v.text.trim().length > 0 || v.mediaIds.length > 0, {
  message: "A post must contain text or media."
});

export type PublicProfile = z.infer<typeof PublicProfileSchema>;
export type CreatePostInput = z.infer<typeof CreatePostSchema>;
export type Visibility = z.infer<typeof VisibilitySchema>;

/**
 * JSON cannot carry BigInt. Convert a BigInt (e.g. MediaAsset.byteSize) to a
 * number only when it is exactly representable; otherwise throw instead of
 * silently losing precision.
 */
export function bigIntToSafeNumber(value: bigint): number {
  if (value > BigInt(Number.MAX_SAFE_INTEGER) || value < BigInt(Number.MIN_SAFE_INTEGER)) {
    throw new RangeError("BigInt value is outside the safe integer range");
  }
  return Number(value);
}

// ---------- Authentication contracts (v0.3.0) ----------
export const EmailSchema = z.string().trim().toLowerCase().email().max(254);
export const PasswordSchema = z.string().min(10, "Use at least 10 characters.").max(128);
export const HandleSchema = z.string().trim().regex(/^[A-Za-z0-9_]{3,30}$/, "3-30 letters, numbers or underscores.");
export const CodeSchema = z.string().regex(/^\d{6}$/, "Code must be 6 digits.");

export const SignupSchema = z.object({
  email: EmailSchema,
  password: PasswordSchema,
  handle: HandleSchema,
  displayName: z.string().trim().min(1).max(80)
});
export const LoginSchema = z.object({ email: EmailSchema, password: z.string().min(1).max(128) });
export const VerifyEmailSchema = z.object({ email: EmailSchema, code: CodeSchema });
export const EmailOnlySchema = z.object({ email: EmailSchema });
export const ResetPasswordSchema = z.object({ email: EmailSchema, code: CodeSchema, newPassword: PasswordSchema });

export type SignupInput = z.infer<typeof SignupSchema>;
