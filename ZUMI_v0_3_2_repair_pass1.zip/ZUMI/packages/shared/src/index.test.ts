import { describe, expect, it } from "vitest";
import { CreatePostSchema, VisibilitySchema, bigIntToSafeNumber } from "./index.js";

describe("CreatePostSchema", () => {
  it("accepts text with an explicit audience", () => {
    const r = CreatePostSchema.safeParse({ text: "hello", visibility: "private" });
    expect(r.success).toBe(true);
  });
  it("requires an explicit visibility (no silent default audience)", () => {
    expect(CreatePostSchema.safeParse({ text: "hello" }).success).toBe(false);
  });
  it("rejects empty posts", () => {
    expect(CreatePostSchema.safeParse({ text: "   ", visibility: "public" }).success).toBe(false);
  });
  it("rejects unknown visibility values", () => {
    expect(VisibilitySchema.safeParse("everyone").success).toBe(false);
  });
  it("rejects more than 10 media items", () => {
    const mediaIds = Array.from({ length: 11 }, () => "7b0f3a52-6d5b-4a8e-9c1e-2f4d8a1b3c5d");
    expect(CreatePostSchema.safeParse({ text: "x", visibility: "private", mediaIds }).success).toBe(false);
  });
});

describe("bigIntToSafeNumber", () => {
  it("converts safe values", () => expect(bigIntToSafeNumber(1024n)).toBe(1024));
  it("throws for unsafe values", () => {
    expect(() => bigIntToSafeNumber(BigInt(Number.MAX_SAFE_INTEGER) + 1n)).toThrow(RangeError);
  });
});

import { SignupSchema, ResetPasswordSchema } from "./index.js";

describe("auth schemas", () => {
  it("normalises email and rejects short passwords", () => {
    const ok = SignupSchema.safeParse({ email: " A@B.COM ", password: "long-enough-1", handle: "sam_1", displayName: "Sam" });
    expect(ok.success && ok.data.email).toBe("a@b.com");
    expect(SignupSchema.safeParse({ email: "a@b.com", password: "short", handle: "sam_1", displayName: "Sam" }).success).toBe(false);
  });
  it("rejects bad handles and non-6-digit codes", () => {
    expect(SignupSchema.safeParse({ email: "a@b.com", password: "long-enough-1", handle: "no spaces", displayName: "S" }).success).toBe(false);
    expect(ResetPasswordSchema.safeParse({ email: "a@b.com", code: "12345", newPassword: "long-enough-1" }).success).toBe(false);
  });
});
