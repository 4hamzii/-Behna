import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import type { FastifyInstance } from "fastify";
import { buildApp } from "../src/app.js";
import { createPrismaStore } from "../src/auth/prismaStore.js";
import { hashPassword } from "../src/auth/crypto.js";
import type { Mailer } from "../src/auth/store.js";

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) } as never);
const mails: { to: string; subject: string; text: string }[] = [];
const mailer: Mailer = { async send(to, subject, text) { mails.push({ to, subject, text }); } };
const store = createPrismaStore(db);
let app: FastifyInstance;
let ipCounter = 1;
const nextIp = () => `10.${Math.floor(ipCounter / 250)}.${ipCounter++ % 250}.7`;
const run = Date.now().toString(36);
const mk = (n: string) => ({ email: `${n}.${run}@example.com`, handle: `${n}_${run}`.slice(0, 30) });
const post = (url: string, payload: object, cookie?: string, ip = nextIp()) =>
  app.inject({ method: "POST", url, payload, remoteAddress: ip, headers: { origin: "http://localhost:3000", ...(cookie ? { cookie } : {}) } });
const codeFor = (email: string) => {
  const m = [...mails].reverse().find((x) => x.to === email && /code is (\d{6})/.test(x.text));
  return m ? /code is (\d{6})/.exec(m.text)![1]! : null;
};
const PW = "correct-horse-battery-9";

beforeAll(async () => {
  app = await buildApp({
    corsOrigin: "http://localhost:3000", logger: false, rateLimitMax: 100000,
    auth: { store, mailer, secret: "x".repeat(48), secureCookie: false }
  });
});
afterAll(async () => { await app.close(); await db.$disconnect(); });

describe("LIVE PostgreSQL: normal auth flow", () => {
  const u = mk("flow");
  it("signup -> verify -> login -> /me -> logout -> /me 401, with correct DB rows", async () => {
    expect((await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "Flow User" })).statusCode).toBe(202);
    const row = await db.user.findUnique({ where: { email: u.email }, include: { profile: true, privacySettings: true, credentials: true } });
    expect(row?.status).toBe("PENDING");
    expect(row?.profile?.handleLower).toBe(u.handle.toLowerCase());
    expect(row?.privacySettings?.defaultPostVisibility).toBe("PRIVATE");
    expect(row?.privacySettings?.discoverable).toBe(false);
    expect(row?.credentials[0]?.secretHash?.startsWith("scrypt$")).toBe(true);
    expect((await post("/api/v1/auth/login", { email: u.email, password: PW })).statusCode).toBe(403);
    expect((await post("/api/v1/auth/verify-email", { email: u.email, code: "000000" })).statusCode).toBe(400);
    expect((await post("/api/v1/auth/verify-email", { email: u.email, code: codeFor(u.email)! })).statusCode).toBe(200);
    expect((await db.user.findUnique({ where: { email: u.email } }))?.status).toBe("ACTIVE");
    const login = await post("/api/v1/auth/login", { email: u.email, password: PW });
    expect(login.statusCode).toBe(200);
    const cookie = `${login.cookies[0]!.name}=${login.cookies[0]!.value}`;
    const me = await app.inject({ method: "GET", url: "/api/v1/auth/me", headers: { cookie } });
    expect(me.statusCode).toBe(200);
    expect((await post("/api/v1/auth/logout", {}, cookie)).statusCode).toBe(204);
    expect((await app.inject({ method: "GET", url: "/api/v1/auth/me", headers: { cookie } })).statusCode).toBe(401);
    const actions = (await db.auditEvent.findMany({ where: { actorId: row!.id } })).map((a) => a.action);
    expect(actions).toEqual(expect.arrayContaining(["auth.signup", "auth.email_verified", "auth.login"]));
  });
  it("stores no plaintext password or raw session token anywhere in the DB", async () => {
    const dump = JSON.stringify(await db.$queryRawUnsafe(`select * from "Credential" union all select null`).catch(() => []));
    expect(dump.includes(PW)).toBe(false);
  });
});

describe("LIVE PostgreSQL: uniqueness and races", () => {
  it("handles are case-insensitive unique (Sam vs sam) -> 409", async () => {
    const a = mk("casey"); const b = mk("casey2");
    await post("/api/v1/auth/signup", { ...a, handle: `CaseyH${run}`, password: PW, displayName: "A" });
    const r = await post("/api/v1/auth/signup", { ...b, handle: `caseyh${run}`, password: PW, displayName: "B" });
    expect(r.statusCode).toBe(409);
  });
  it("duplicate email answers 202 exactly like a new signup", async () => {
    const a = mk("dupe");
    const first = await post("/api/v1/auth/signup", { ...a, password: PW, displayName: "A" });
    const second = await post("/api/v1/auth/signup", { ...a, handle: `other_${run}`.slice(0, 30), password: PW, displayName: "A" });
    expect(second.statusCode).toBe(first.statusCode);
    expect(second.body).toBe(first.body);
  });
  it("5 simultaneous identical signups: no 500s, exactly one account", async () => {
    const a = mk("race");
    const rs = await Promise.all(Array.from({ length: 5 }, () => post("/api/v1/auth/signup", { ...a, password: PW, displayName: "R" })));
    expect(rs.map((r) => r.statusCode).filter((c) => c >= 500)).toEqual([]);
    expect(await db.user.count({ where: { email: a.email } })).toBe(1);
  });
});

describe("LIVE PostgreSQL: code guessing limit (5 attempts per code)", () => {
  it("30 parallel wrong guesses must not all be evaluated", async () => {
    const u = mk("guess");
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "G" });
    const user = await db.user.findUnique({ where: { email: u.email } });
    await Promise.all(Array.from({ length: 30 }, (_, i) => post("/api/v1/auth/verify-email", { email: u.email, code: String(100000 + i) })));
    const tok = await db.verificationToken.findFirst({ where: { userId: user!.id } });
    console.log(`[EVIDENCE] attempts recorded after 30 parallel wrong guesses = ${tok!.attempts} (limit is 5)`);
    expect(tok!.attempts).toBeLessThanOrEqual(5);
  });
});

describe("LIVE PostgreSQL: account pre-hijack and stuck-signup probes", () => {
  it("attacker who pre-registers a victim's email must not keep access after the victim verifies", async () => {
    const v = mk("victim");
    await post("/api/v1/auth/signup", { ...v, handle: `atk_${run}`.slice(0, 30), password: "attacker-knows-this-1", displayName: "Attacker" });
    // Victim later asks for a code for their own email and verifies it.
    await post("/api/v1/auth/resend", { email: v.email });
    expect((await post("/api/v1/auth/verify-email", { email: v.email, code: codeFor(v.email)! })).statusCode).toBe(200);
    const atkLogin = await post("/api/v1/auth/login", { email: v.email, password: "attacker-knows-this-1" });
    console.log(`[EVIDENCE] attacker login after victim verified -> HTTP ${atkLogin.statusCode}`);
    expect(atkLogin.statusCode).toBe(401);
  });
  it("signing up again with a still-unverified email gives the person a usable new code", async () => {
    const u = mk("stuck");
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "S" });
    mails.length = 0;
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "S" });
    const got = mails.filter((m) => m.to === u.email);
    console.log(`[EVIDENCE] re-signup mail: "${got[0]?.subject}" contains code: ${/\d{6}/.test(got[0]?.text ?? "")}`);
    expect(got.some((m) => /code is \d{6}/.test(m.text))).toBe(true);
  });
  it("stale never-verified accounts are eventually cleaned up so handles/emails are not held forever", async () => {
    const u = mk("stale");
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "S" });
    await db.user.update({ where: { email: u.email }, data: { createdAt: new Date(Date.now() - 90 * 86400000) } });
    await store.purgeExpired(new Date());
    expect(await db.user.count({ where: { email: u.email } })).toBe(0);
  });
});

describe("LIVE PostgreSQL: password reset and housekeeping", () => {
  it("reset revokes all sessions and the old password stops working", async () => {
    const u = mk("reset");
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "R" });
    await post("/api/v1/auth/verify-email", { email: u.email, code: codeFor(u.email)! });
    const l1 = await post("/api/v1/auth/login", { email: u.email, password: PW });
    const c1 = `${l1.cookies[0]!.name}=${l1.cookies[0]!.value}`;
    await post("/api/v1/auth/forgot", { email: u.email });
    expect((await post("/api/v1/auth/reset", { email: u.email, code: codeFor(u.email)!, newPassword: "brand-new-pass-77" })).statusCode).toBe(200);
    expect((await app.inject({ method: "GET", url: "/api/v1/auth/me", headers: { cookie: c1 } })).statusCode).toBe(401);
    expect((await post("/api/v1/auth/login", { email: u.email, password: PW })).statusCode).toBe(401);
    expect((await post("/api/v1/auth/login", { email: u.email, password: "brand-new-pass-77" })).statusCode).toBe(200);
    expect(await db.credential.count({ where: { user: { email: u.email }, type: "PASSWORD", revokedAt: null } })).toBe(1);
  });
  it("idle session (15 days) is rejected; purgeExpired deletes long-dead sessions", async () => {
    const u = mk("idle");
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "I" });
    await post("/api/v1/auth/verify-email", { email: u.email, code: codeFor(u.email)! });
    const l = await post("/api/v1/auth/login", { email: u.email, password: PW });
    const cookie = `${l.cookies[0]!.name}=${l.cookies[0]!.value}`;
    const user = await db.user.findUnique({ where: { email: u.email } });
    await db.session.updateMany({ where: { userId: user!.id }, data: { lastUsedAt: new Date(Date.now() - 15 * 86400000) } });
    expect((await app.inject({ method: "GET", url: "/api/v1/auth/me", headers: { cookie } })).statusCode).toBe(401);
    await db.session.updateMany({ where: { userId: user!.id }, data: { expiresAt: new Date(Date.now() - 10 * 86400000) } });
    await store.purgeExpired(new Date());
    expect(await db.session.count({ where: { userId: user!.id } })).toBe(0);
  });
});

describe("LIVE: server responsiveness while passwords are hashed", () => {
  it("/health stays fast while 12 logins run at once", async () => {
    const t0 = performance.now(); await hashPassword("timing-probe-password"); const oneHash = performance.now() - t0;
    const u = mk("load");
    await post("/api/v1/auth/signup", { ...u, password: PW, displayName: "L" });
    let worst = 0; let stop = false;
    const probe = (async () => { while (!stop) { const s = performance.now(); await app.inject({ method: "GET", url: "/health" }); worst = Math.max(worst, performance.now() - s); await new Promise((r) => setTimeout(r, 5)); } })();
    await Promise.all(Array.from({ length: 12 }, () => post("/api/v1/auth/login", { email: u.email, password: "wrong-password-xx" })));
    stop = true; await probe;
    console.log(`[EVIDENCE] one scrypt hash = ${oneHash.toFixed(0)} ms (blocks the server); worst /health latency during 12 logins = ${worst.toFixed(0)} ms`);
    expect(worst).toBeLessThan(250);
  });
});
