import path from "node:path";
import { defineConfig } from "prisma/config";
import { PrismaPg } from "@prisma/adapter-pg";
export default defineConfig({
  experimental: { adapter: true },
  engine: "js",
  schema: path.join("prisma", "schema.prisma"),
  async adapter() { return new PrismaPg({ connectionString: process.env.DATABASE_URL }); }
} as any);
