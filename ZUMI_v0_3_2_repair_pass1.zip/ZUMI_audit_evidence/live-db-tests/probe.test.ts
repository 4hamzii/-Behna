import { it, expect, beforeAll, afterAll } from "vitest";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { monitorEventLoopDelay } from "node:perf_hooks";
import { buildApp } from "../src/app.js";
import { createPrismaStore } from "../src/auth/prismaStore.js";
import type { FastifyInstance } from "fastify";

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) } as never);
const mails: string[] = [];
let app: FastifyInstance; let n = 1;
const run = Date.now().toString(36);
const post = (url: string, payload: object, ip = `10.9.${n++ % 250}.1`) =>
  app.inject({ method: "POST", url, payload, remoteAddress: ip, headers: { origin: "http://localhost:3000" } });
beforeAll(async () => { app = await buildApp({ corsOrigin: "http://localhost:3000", logger: false, auth: { store: createPrismaStore(db), mailer: { async send(_t, _s, x) { mails.push(x); } }, secret: "y".repeat(48), secureCookie: false } }); });
afterAll(async () => { await app.close(); await db.$disconnect(); });

it("P2002 error shape from the engine-free driver (to separate harness quirk from repo bug)", async () => {
  await db.user.create({ data: { email: `meta1.${run}@example.com`, profile: { create: { handle: `Meta${run}`, handleLower: `meta${run}`, displayName: "x" } } } });
  try {
    await db.user.create({ data: { email: `meta2.${run}@example.com`, profile: { create: { handle: `META${run}`, handleLower: `meta${run}`, displayName: "x" } } } });
  } catch (e: any) { console.log("[META]", e.constructor.name, e.code, JSON.stringify(e.meta)); }
});

it("event-loop delay while 12 wrong-password logins are processed", async () => {
  const email = `lag.${run}@example.com`;
  await post("/api/v1/auth/signup", { email, handle: `lag_${run}`.slice(0, 30), password: "correct-horse-battery-9", displayName: "L" });
  const h = monitorEventLoopDelay({ resolution: 1 }); h.enable();
  await Promise.all(Array.from({ length: 12 }, () => post("/api/v1/auth/login", { email, password: "wrong-password-xx" })));
  h.disable();
  console.log(`[LAG] max event-loop delay during 12 parallel logins = ${(h.max / 1e6).toFixed(0)} ms, p99 = ${(h.percentile(99) / 1e6).toFixed(0)} ms`);
});

it("cookie flags, unknown-email vs wrong-password parity, login rate limit", async () => {
  const email = `cookie.${run}@example.com`;
  await post("/api/v1/auth/signup", { email, handle: `ck_${run}`.slice(0, 30), password: "correct-horse-battery-9", displayName: "C" });
  const code = /(\d{6})/.exec(mails.at(-1)!)![1]!;
  await post("/api/v1/auth/verify-email", { email, code });
  const ok = await post("/api/v1/auth/login", { email, password: "correct-horse-battery-9" });
  console.log("[COOKIE]", ok.headers["set-cookie"]);
  const a = await post("/api/v1/auth/login", { email, password: "nope-nope-nope" });
  const b = await post("/api/v1/auth/login", { email: `ghost.${run}@example.com`, password: "nope-nope-nope" });
  console.log("[PARITY]", a.statusCode, a.body === b.body ? "identical body" : "DIFFERENT body");
  const codes: number[] = [];
  for (let i = 0; i < 12; i++) codes.push((await post("/api/v1/auth/login", { email, password: "x-x-x-x-x-x" }, "10.200.0.5")).statusCode);
  console.log("[RATELIMIT] same-IP login attempts ->", codes.join(","));
  const big = await app.inject({ method: "POST", url: "/api/v1/auth/login", payload: "x".repeat(1_200_000), headers: { "content-type": "application/json", origin: "http://localhost:3000" }, remoteAddress: "10.201.0.1" });
  console.log("[BODYLIMIT] 1.2MB body ->", big.statusCode);
  const foreign = await app.inject({ method: "POST", url: "/api/v1/auth/login", payload: { email, password: "x" }, headers: { origin: "https://evil.example" }, remoteAddress: "10.202.0.1" });
  console.log("[CSRF] foreign Origin ->", foreign.statusCode);
  const me = await app.inject({ method: "GET", url: "/api/v1/auth/me" });
  console.log("[ME] no cookie ->", me.statusCode);
  expect(true).toBe(true);
});
