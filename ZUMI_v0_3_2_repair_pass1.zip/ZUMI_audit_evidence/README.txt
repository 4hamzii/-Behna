These are SCRATCH tests, not part of the ZUMI project. They ran the project's own API/auth code
(copied byte-for-byte, verified with cmp) against a real PostgreSQL 16 using Prisma's engine-free client
(@prisma/adapter-pg), because the audit sandbox could not download Prisma's native engine.
live.test.ts  - 12 tests: normal flow, uniqueness, races, code-guess limit, takeover probes, reset, housekeeping.
probe.test.ts - error shape, event-loop delay, cookie flags, rate limit, body limit, CSRF.
Results before/after the repairs are in docs/audit/AUDIT_2026-11-15_INDEPENDENT.md inside ZUMI/.
Four live tests still FAIL on purpose: they describe open findings N-01, N-02, N-03 (real) and N-08 (unverified).
